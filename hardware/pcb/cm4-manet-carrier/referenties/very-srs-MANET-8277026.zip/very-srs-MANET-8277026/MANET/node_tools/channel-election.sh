#!/bin/bash
# ==============================================================================
# Channel Election Manager
# ==============================================================================
# This script performs a decentralized, deterministic election for the best
# 2.4GHz and 5GHz channels. If all channels are terrible, falls back to lobby.
# ==============================================================================

set -eo pipefail

# --- Dry Run Mode (set to true for testing) ---
DRY_RUN=false

# --- Configuration ---
REGISTRY_FILE="/var/run/mesh_node_registry"
OUTPUT_FILE="/var/run/mesh_channel_election"
LOCK_FILE="/var/run/channel-election.lock"
WPA_IFACE_2_4=""
WPA_IFACE_5_0=""
WPA_CONF_2_4=""
WPA_CONF_5_0=""

# --- Tunable Parameters ---
STALE_THRESHOLD=240 # (4 minutes) Ignore scan reports older than this (scans are every 3 min)
NOISE_DISQUALIFY_THRESHOLD_DBM=-70 # Disqualify channel if ANY node reports noise worse than this
CHANNEL_BIAS_DB=10 # A new channel must be at least this much quieter (in dB) to trigger a move
# Score = avg_noise + bss_count*0.1, lower is better. A channel at the -70 dBm
# disqualification edge needs ~100 BSSes to reach -60; anything above that is
# unusable enough to trigger limp mode.
LIMP_MODE_SCORE_THRESHOLD=-60 # If the *best* channel's score is worse (higher) than this, trigger limp mode

# Lobby channels
LOBBY_FREQ_2_4=2412
LOBBY_FREQ_5_0=5180

# List of channels this mesh is allowed to use. The lobby frequencies are
# deliberately excluded: if the election landed on the lobby pair, every node
# would flip into lobby state (is_in_lobby checks frequencies) and scanning,
# elections and tourguide duty would silently stop.
#
# These are deliberately NOT filtered against the local phy's capabilities here.
# The election is an implicit-consensus algorithm: every node must run the same
# computation over the same replicated inputs, so injecting a per-node hardware
# filter at this stage would let two nodes reach different answers from
# identical data. Unusable frequencies are excluded at scan time instead
# (phy_usable_freqs in node-manager-acs.sh), which keeps the exclusion visible
# in the replicated reports and therefore symmetric across the mesh.
CHANNELS_2_4="2437 2462"
CHANNELS_5_0="5200 5220 5240 5745 5765 5785 5805 5825"

# --- Helper Functions ---
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] - CHAN-ELECTION: $1" | systemd-cat -t channel-election
}

# Get the currently configured frequency for an interface
get_current_freq() {
    local conf_file=$1
    if [ -f "$conf_file" ]; then
        grep -oP 'frequency=\K[0-9]+' "$conf_file" | head -1
    else
        echo ""
    fi
}

radio_iface_enabled() {
    python3 - "$1" <<'PY'
import json, sys
iface = sys.argv[1]
try:
    with open('/var/lib/mesh_radio_state.json') as f:
        state = json.load(f).get('desired', {}).get(iface, 'up')
except Exception:
    state = 'up'
sys.exit(1 if state == 'down' else 0)
PY
}

load_mesh_roles() {
    local mesh_ifaces=()

    [ -f /var/lib/mesh_if ] && mapfile -t mesh_ifaces < /var/lib/mesh_if

    WPA_IFACE_2_4="$(cat /var/lib/mesh_24_if 2>/dev/null || true)"
    WPA_IFACE_5_0="$(cat /var/lib/mesh_5_if 2>/dev/null || true)"

    [ -z "$WPA_IFACE_2_4" ] && WPA_IFACE_2_4="${mesh_ifaces[0]:-}"
    [ -z "$WPA_IFACE_5_0" ] && WPA_IFACE_5_0="${mesh_ifaces[1]:-}"

    WPA_CONF_2_4="/etc/wpa_supplicant/wpa_supplicant-${WPA_IFACE_2_4}.conf"
    WPA_CONF_5_0="/etc/wpa_supplicant/wpa_supplicant-${WPA_IFACE_5_0}.conf"
}

# --- Main Logic ---

# Use flock to ensure this script only runs once
(
    flock -n 9 || { log "Channel election already in progress. Exiting."; exit 1; }
    log "--- Starting Channel Election ---"
    load_mesh_roles
    if [ -z "$WPA_IFACE_2_4" ] || [ -z "$WPA_IFACE_5_0" ]; then
        log "Mesh role files not ready; cannot run channel election."
        exit 1
    fi

    # Check for jq
    if ! command -v jq &>/dev/null; then
        log "ERROR: 'jq' command not found. Please install it (apt install jq). Exiting."
        exit 1
    fi

    # Check for registry
    if [ ! -f "$REGISTRY_FILE" ]; then
        log "Registry file not found, cannot run election. Exiting."
        exit 1
    fi

    NOW=$(date +%s)

    # 1. Aggregate all *active* scan reports from the registry.
    # Key by the NODE_<mac> prefix in $1 and pair report/timestamp in END:
    # the registry writes CHANNEL_REPORT_JSON before LAST_SEEN_TIMESTAMP, so
    # a single pass keyed on $2 (always empty with this FS) dropped the first
    # node's report and matched each report against the previous node's age.
    ALL_REPORTS_JSON=$(awk -F"['=]" \
        -v now="$NOW" -v stale="$STALE_THRESHOLD" \
        '/_LAST_SEEN_TIMESTAMP=/ { k=$1; sub(/_LAST_SEEN_TIMESTAMP$/, "", k); ts[k]=$3 }
         /_CHANNEL_REPORT_JSON=/ { k=$1; sub(/_CHANNEL_REPORT_JSON$/, "", k); rpt[k]=$3 }
         END{
             print "[";
             for (k in rpt) {
                 if (rpt[k] != "" && (k in ts) && (now - ts[k]) < stale) {
                     if (count > 0) print ",";
                     print rpt[k];
                     count++
                 }
             }
             print "]"
         }' "$REGISTRY_FILE")

    if [ "$(echo "$ALL_REPORTS_JSON" | jq 'length')" -eq 0 ]; then
        log "No active scan reports in registry. Exiting."
        exit 0
    fi

    # Initialize Limp Mode variable
    LIMP_MODE_NEEDED="false"

    # Function to score a band and find the winner
    find_best_channel() {
        local band_channels="$1"
        local current_channel="$2"
        local band_name="$3"
        local -n _winner=$4
        local winner_channel=""
        local winner_score=1000 # Lower is better

        local candidates=()
        # Distinguishes "every candidate was measured and rejected" (a real RF
        # verdict) from "nothing reported any measurement at all" (an outage).
        # Both leave candidates[] empty; they must not be handled the same way.
        local had_any_data=false

        for chan in $band_channels; do
            local stats=$(echo "$ALL_REPORTS_JSON" | jq -r --argjson c "$chan" '
                [
                    flatten | .[] | .results | .[] |
                    select(.channel == $c) |
                    {noise: .noise_floor, bss: .bss_count}
                ] |
                if length > 0 then
                    {
                        "max_noise": (map(.noise) | max),
                        "avg_noise": (map(.noise) | add / length),
                        "total_bss": (map(.bss) | add)
                    }
                else
                    null
                end
            ')

            if [ "$stats" == "null" ]; then
                log "[$band_name] No scan data for channel $chan"
                continue
            fi
            had_any_data=true

            local max_noise=$(echo "$stats" | jq '.max_noise')
            local avg_noise=$(echo "$stats" | jq '.avg_noise')
            local total_bss=$(echo "$stats" | jq '.total_bss')

            # --- Filter Disqualified Channels ---
            if (( $(echo "$max_noise > $NOISE_DISQUALIFY_THRESHOLD_DBM" | bc -l) )); then
                log "[$band_name] Channel $chan disqualified (max_noise ${max_noise}dBm)"
                continue
            fi

            # --- Calculate Final Score (lower is better: quieter + fewer BSSes wins) ---
            local score=$(echo "$avg_noise + ($total_bss * 0.1)" | bc -l)

            # --- Apply Bias ---
            if [ "$chan" == "$current_channel" ]; then
                score=$(echo "$score - $CHANNEL_BIAS_DB" | bc -l)
                log "[$band_name] Applying bias to current channel $chan. Score: $score"
            fi

            candidates+=("$(printf "%.2f %s\n" "$score" "$chan")")
        done

        # --- Sort and Pick Winner ---
        if [ ${#candidates[@]} -eq 0 ] && [ "$had_any_data" = false ]; then
            # Not an RF verdict -- no node reported a usable measurement for any
            # candidate on this band. Causes seen in practice: the radio for this
            # band is absent (so its scan report carries no entries for it), the
            # scan request was rejected wholesale, or alfred was silently down so
            # no reports replicated. Dropping to lobby and asserting limp mode
            # here throttles the whole mesh to legacy bitrates on the strength of
            # missing data. Hold the current channel and change nothing; the next
            # cycle re-elects once measurements come back.
            log "[$band_name] No scan data for any candidate channel. Holding ${current_channel:-current channel}, not asserting limp mode."
            _winner="$current_channel"
            return 0
        fi

        if [ ${#candidates[@]} -eq 0 ]; then
            log "[$band_name] ALL CHANNELS DISQUALIFIED. Falling back to lobby."
            LIMP_MODE_NEEDED="true"

            if [ "$band_name" == "2.4GHz" ]; then
                _winner="$LOBBY_FREQ_2_4"
            else
                _winner="$LOBBY_FREQ_5_0"
            fi
        else
            local winner_line=$(printf '%s\n' "${candidates[@]}" | sort -n -k1,1 -k2,2 | head -1)
            winner_channel=$(echo "$winner_line" | awk '{print $2}')
            winner_score=$(echo "$winner_line" | awk '{print $1}')

            # Check if the *best* channel is still terrible
            if (( $(echo "$winner_score > $LIMP_MODE_SCORE_THRESHOLD" | bc -l) )); then
                log "[$band_name] JAMMING DETECTED. Best channel $winner_channel has poor score ($winner_score). Falling back to lobby."
                LIMP_MODE_NEEDED="true"

                if [ "$band_name" == "2.4GHz" ]; then
                    _winner="$LOBBY_FREQ_2_4"
                else
                    _winner="$LOBBY_FREQ_5_0"
                fi
            else
                log "[$band_name] Winner is $winner_channel (Score: $winner_score)"
                _winner="$winner_channel"
            fi
        fi
    }

    # --- Get Current State ---
    CURRENT_2_4=$(get_current_freq "$WPA_CONF_2_4")
    CURRENT_5_0=$(get_current_freq "$WPA_CONF_5_0")
    log "Current channels: 2.4G=${CURRENT_2_4:-none}, 5.0G=${CURRENT_5_0:-none}"

    # --- Run Elections ---
    find_best_channel "$CHANNELS_2_4" "$CURRENT_2_4" "2.4GHz" WINNER_2_4
    find_best_channel "$CHANNELS_5_0" "$CURRENT_5_0" "5.0GHz" WINNER_5_0

    # --- Write Output File (for node-manager) ---
    cat > "$OUTPUT_FILE" <<- EOF
		WINNER_2_4=$WINNER_2_4
		WINNER_5_0=$WINNER_5_0
		LIMP_MODE=$LIMP_MODE_NEEDED
	EOF

    # --- Act on Changes ---
    MIGRATION_2_4_NEEDED=false
    MIGRATION_5_0_NEEDED=false

    if [[ -n "$WINNER_2_4" && "$WINNER_2_4" != "$CURRENT_2_4" ]]; then
        log ">>> MIGRATION: 2.4GHz channel changing: $CURRENT_2_4 -> $WINNER_2_4"

        if [ "$DRY_RUN" = false ]; then
      	  sed -i "s/frequency=.*/frequency=${WINNER_2_4}/" "$WPA_CONF_2_4"
      	  MIGRATION_2_4_NEEDED=true
    	else
    	    log "DRY RUN: Would migrate 2.4GHz but not actually doing it"
    	fi
    fi

    if [[ -n "$WINNER_5_0" && "$WINNER_5_0" != "$CURRENT_5_0" ]]; then
        log ">>> MIGRATION: 5.0GHz channel changing: $CURRENT_5_0 -> $WINNER_5_0"

	    if [ "$DRY_RUN" = false ]; then
    	    sed -i "s/frequency=.*/frequency=${WINNER_5_0}/" "$WPA_CONF_5_0"
        	MIGRATION_5_0_NEEDED=true
    	else
    	    log "DRY RUN: Would migrate 5.0GHz but not actually doing it"
    	fi

    fi

    # Restart services *after* all configs are written
	if [ "$DRY_RUN" = false ]; then
        if [ "$MIGRATION_2_4_NEEDED" = true ]; then
            if radio_iface_enabled "$WPA_IFACE_2_4"; then
                log "Restarting wpa_supplicant@${WPA_IFACE_2_4}.service..."
                systemctl restart "wpa_supplicant@${WPA_IFACE_2_4}.service"
            else
                log "Skipping restart for ${WPA_IFACE_2_4}; radio-state says down"
            fi
        fi

        if [ "$MIGRATION_5_0_NEEDED" = true ]; then
            if radio_iface_enabled "$WPA_IFACE_5_0"; then
                log "Restarting wpa_supplicant@${WPA_IFACE_5_0}.service..."
                systemctl restart "wpa_supplicant@${WPA_IFACE_5_0}.service"
            else
                log "Skipping restart for ${WPA_IFACE_5_0}; radio-state says down"
            fi
        fi
	else
    	log "DRY RUN: Skipping service restarts"
	fi
   	log "--- Election Complete ---"

) 9>/var/run/channel-election.lock
