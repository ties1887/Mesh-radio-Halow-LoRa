#!/bin/bash
#  A script to finalize the setup of a radio after imaging and a first boot
# 
#  This script can be re-run to set new network settings
#  if the mesh config file is updated
#

# log the output of this script to a file for debugging. Append, never
# truncate: this script runs more than once (first boot, post-rename re-run,
# manual retry) and overwriting destroyed the history of the run that actually
# went wrong. Two runs writing a truncating tee also interleave into an
# unreadable file.
exec >> >(tee -a /var/log/radio-setup.log) 2>&1
set -x

echo "=============================================================="
echo " radio-setup starting: $(date -Is)"
echo "=============================================================="

led_error() {
    echo heartbeat > /sys/class/leds/PWR/trigger
}
trap led_error ERR

# ── Provisioning state ──────────────────────────────────────────────────────
# A node takes several reboots and about ten minutes to provision. Nothing used
# to record whether that finished, so a node whose Ethernet was unplugged
# part-way through looked exactly like a finished one — and got marked done.
# These files are what `manet-provision-status.sh` reports on login.
PROVISION_STATE_FILE="/var/lib/manet-provision.state"
PROVISION_FAIL_FILE="/var/lib/manet-provision.failures"
PROVISION_STARTED=$(date +%s)

provision_state() {
    mkdir -p /var/lib
    {
        echo "STATE=$1"
        echo "PHASE=radio-setup"
        echo "STARTED=$PROVISION_STARTED"
        echo "UPDATED=$(date +%s)"
        [ -n "$2" ] && echo "FINISHED=$2"
    } > "$PROVISION_STATE_FILE"
}

# Record a step that did not work. The run continues — a node with no GPS
# tooling is still a useful node — but it will not be marked provisioned.
provision_fail() {
    echo "$1" >> "$PROVISION_FAIL_FILE"
    echo " !! PROVISION FAILURE: $1"
}

# Run a command, recording a failure if it does not succeed.
provision_try() {
    local what="$1"; shift
    if ! "$@"; then
        provision_fail "$what"
        return 1
    fi
    return 0
}

# Is there a working path to the package repositories? Checked before the apt
# phases so "no network" is reported once, plainly, instead of as a wall of
# apt resolver errors.
have_package_network() {
    getent hosts deb.debian.org >/dev/null 2>&1 || return 1
    return 0
}

: > "$PROVISION_FAIL_FILE"
provision_state running

# Show provisioning state on every SSH login. Installed before any of the work
# below, so a node that is still setting itself up says so to anyone who logs
# in to check on it.
if [ -x /usr/local/bin/manet-provision-status.sh ]; then
    mkdir -p /etc/update-motd.d
    ln -sf /usr/local/bin/manet-provision-status.sh /etc/update-motd.d/50-manet-provision
fi
if [ -x /usr/local/bin/manet-power-status.sh ]; then
    mkdir -p /etc/update-motd.d
    ln -sf /usr/local/bin/manet-power-status.sh /etc/update-motd.d/55-manet-power
fi

# This loop reads the stored setup variables to set the current config
while IFS= read -r line; do
    # Skip empty lines
    if [[ -z "$line" ]]; then
        continue
    fi

    # Split the line into a key and a value at the first ": "
    key="${line%%=*}"
    value="${line#*=}"

    sanitized_key=$(echo "$key" | sed 's/-/_/g' | tr -cd '[:alnum:]_')

    # Check if the key is not empty after sanitization
    if [[ -n "$sanitized_key" ]]; then
        # Export the sanitized key as an environment variable with its value.
        export "$sanitized_key=$value"
        echo "Checking config: $sanitized_key"
    fi
done < <(cat /etc/mesh.conf)

# Look up the current physical interface name for a logical name.
# During provisioning, logical names (wlan0/1/2) may not yet match kernel names.
phys_iface() {
    local logical="$1"
    local phys
    phys=$(grep "^${logical}:" /var/lib/iface_map 2>/dev/null | cut -d: -f2)
    echo "${phys:-$logical}"   # fall back to logical name if no mapping (post-reboot)
}

set_mesh_hostname() {
    local new_hostname="$1"
    [ -n "$new_hostname" ] || return 0

    if hostnamectl set-hostname "$new_hostname" 2>/dev/null; then
        return 0
    fi

    echo "$new_hostname" > /etc/hostname 2>/dev/null || true
    if grep -q '^127\.0\.1\.1' /etc/hosts 2>/dev/null; then
        sed -i "s/^127\\.0\\.1\\.1.*/127.0.1.1\t${new_hostname}/" /etc/hosts
    else
        echo "127.0.1.1	${new_hostname}" >> /etc/hosts
    fi
    hostname "$new_hostname" 2>/dev/null || hostnamectl --transient set-hostname "$new_hostname" 2>/dev/null || true
}

has_usb_morse_device() {
    local dev text

    for dev in /sys/bus/usb/devices/*; do
        [ -d "$dev" ] || continue
        text="$(cat "$dev/product" "$dev/manufacturer" 2>/dev/null | tr '[:upper:]' '[:lower:]')"
        echo "$text" | grep -Eq 'morse|mm81|halow|802\.11ah' && return 0
    done

    return 1
}

has_morse_netdev() {
    local iface driver

    for iface in /sys/class/net/*; do
        [ -e "$iface" ] || continue
        driver="$(basename "$(readlink -f "$iface/device/driver" 2>/dev/null)")"
        [[ "$driver" == morse* ]] && return 0
    done

    return 1
}

echo "Installing morse driver"
mkdir -p /lib/modules/$(uname -r)/extra/morse

# Copy Morse modules when provisioning assets are present. On already-provisioned
# nodes the modules may already be installed and /root/morse_driver may be gone.
if [ -f /root/morse_driver/morse.ko ]; then
    cp /root/morse_driver/morse.ko /lib/modules/$(uname -r)/extra/morse/
else
    echo " > /root/morse_driver/morse.ko not found; keeping existing installed module"
fi

if [ -f /root/morse_driver/dot11ah/dot11ah.ko ]; then
    cp /root/morse_driver/dot11ah/dot11ah.ko /lib/modules/$(uname -r)/extra/morse/
else
    echo " > /root/morse_driver/dot11ah/dot11ah.ko not found; keeping existing installed module"
fi

# Update module dependencies
depmod -a

cp /root/morse_cli/morse_cli /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/bin/*

# Write safe Morse options before the first modprobe. Cloned images may carry
# board-specific SPI BCF options that break USB MM81xx probe.
EARLY_REGULATORY_DOMAIN=$(grep "^regulatory_domain=" /etc/mesh.conf 2>/dev/null | cut -d'=' -f2)
EARLY_REGULATORY_DOMAIN=${EARLY_REGULATORY_DOMAIN:-US}
EARLY_HALOW_REGULATORY_DOMAIN=$(grep "^halow_regulatory_domain=" /etc/mesh.conf 2>/dev/null | cut -d'=' -f2)
EARLY_HALOW_REGULATORY_DOMAIN=${EARLY_HALOW_REGULATORY_DOMAIN:-$EARLY_REGULATORY_DOMAIN}
case "$EARLY_REGULATORY_DOMAIN" in
    AT|BE|BG|HR|CY|CZ|DK|EE|FI|FR|DE|GR|HU|IE|IT|LV|LT|LU|MT|NL|PL|PT|RO|SK|SI|ES|SE|GB|CH|NO)
        EARLY_HALOW_REGULATORY_DOMAIN="EU"
        ;;
esac

echo "options cfg80211 ieee80211_regdom=$EARLY_REGULATORY_DOMAIN" > /etc/modprobe.d/cfg80211.conf
EARLY_MORSE_BCF=""
EARLY_MORSE_SPI_CLOCK=""
if [ -f /etc/modprobe.d/morse.conf ] && ! has_usb_morse_device; then
    EARLY_MORSE_BCF=$(grep -oP '(?<=bcf=)\S+' /etc/modprobe.d/morse.conf | head -1)
    EARLY_MORSE_SPI_CLOCK=$(grep -oP '(?<=spi_clock_speed=)\S+' /etc/modprobe.d/morse.conf | head -1)
fi
echo "options morse enable_mcast_whitelist=0 enable_mcast_rate_control=1" > /etc/modprobe.d/morse.conf
echo "options morse country=$EARLY_HALOW_REGULATORY_DOMAIN" >> /etc/modprobe.d/morse.conf
[[ -n "$EARLY_MORSE_BCF" ]] && echo "options morse bcf=$EARLY_MORSE_BCF" >> /etc/modprobe.d/morse.conf
[[ -n "$EARLY_MORSE_SPI_CLOCK" ]] && echo "options morse spi_clock_speed=$EARLY_MORSE_SPI_CLOCK" >> /etc/modprobe.d/morse.conf
if [[ "$EARLY_HALOW_REGULATORY_DOMAIN" == "EU" ]]; then
    echo "options morse enable_auto_duty_cycle=0 enable_auto_mpsw=0" >> /etc/modprobe.d/morse.conf
fi

if has_usb_morse_device && ! has_morse_netdev; then
    modprobe -r morse 2>/dev/null || true
    modprobe -r dot11ah 2>/dev/null || true
fi

# Activating drivers
modprobe dot11ah
modprobe morse


echo "Applying settings..."
sleep 0.5
if [[ -n "$mesh_key" ]]; then
    KEY=$mesh_key
    echo " > Using SAE Key: $KEY"
    sleep 0.5
fi

if [[ -n "$mesh_ssid" ]]; then
    echo " > Setting mesh SSID to: $mesh_ssid"
    MESH_NAME=$mesh_ssid
    sleep 0.5
fi

if [[ -n "$new_root_password" ]]; then
    echo " > Setting root password..."
    echo "root:$new_root_password" | chpasswd
fi

if [[ -n "$new_user_password" ]]; then
    echo " > Setting password for user 'radio'..."
    echo "radio:$new_user_password" | chpasswd
fi

if [[ -n "$ssh_public_key" ]]; then
    echo " > Updating authorized_keys for user 'radio'..."
    mkdir -p /home/radio/.ssh
    echo "$ssh_public_key" >> /home/radio/.ssh/authorized_keys
    awk '!seen[$0]++' /home/radio/.ssh/authorized_keys > /tmp/t
    mv /tmp/t /home/radio/.ssh/authorized_keys
fi

echo " > Ensuring SSH password access for user 'radio'..."
id -u radio >/dev/null 2>&1 || useradd -m -s /bin/bash -G sudo,adm,dialout,cdrom,audio,video,plugdev,games,users,input,netdev,gpio,i2c,spi radio
usermod -aG sudo,adm,dialout,cdrom,audio,video,plugdev,games,users,input,netdev,gpio,i2c,spi radio 2>/dev/null || true
if [[ -n "$new_user_password" ]]; then
    echo "radio:$new_user_password" | chpasswd
elif [[ -n "$radio_password" ]]; then
    echo "radio:$radio_password" | chpasswd
fi
passwd -u radio 2>/dev/null || true
mkdir -p /home/radio/.ssh /etc/ssh/sshd_config.d
chmod 700 /home/radio/.ssh
chown -R radio:radio /home/radio/.ssh
cat << EOF > /etc/ssh/sshd_config.d/10-manet.conf
PasswordAuthentication yes
KbdInteractiveAuthentication no
PubkeyAuthentication yes
UsePAM yes
PermitRootLogin prohibit-password
EOF
systemctl enable ssh 2>/dev/null || true
systemctl restart ssh 2>/dev/null || true

sleep 0.5
echo "testing acs variable"
if [[ -n "$acs" ]]; then
    echo "acs defined as $acs"
    sleep 0.5
    # y/n is what every writer produces: both flashers normalise the answer to
    # lowercase, the web UI writes 'y':'n', and mesh-config-sync.py validates
    # the key as exactly y or n. This tested for "Y" alone, so acs=y selected
    # the static orchestrator on every node and ACS never ran. Liberal about a
    # hand-edited conf; cannot match n/no/0/false.
    if [[ "$acs" =~ ^([Yy]|[Yy][Ee][Ss]|1|[Tt][Rr][Uu][Ee])$ ]]; then
        echo " > This mesh will channel hop ..."
        cp /usr/local/bin/node-manager-acs.sh /usr/local/bin/node-manager.sh
    else
        echo " > This mesh will remain on a static channel ..."
        cp /usr/local/bin/node-manager-static.sh /usr/local/bin/node-manager.sh
    fi

fi

sleep 2

#
# Finish setting up network devices (wireless)
#

cat << 'EOF' > /usr/local/bin/unblock-wifi-rfkill.sh
#!/bin/sh
for rfkill in /sys/class/rfkill/rfkill*; do
    [ -e "$rfkill/type" ] || continue
    [ "$(cat "$rfkill/type" 2>/dev/null)" = "wlan" ] || continue
    [ "$(cat "$rfkill/hard" 2>/dev/null)" = "1" ] && continue
    echo 0 > "$rfkill/soft" 2>/dev/null || true
done
EOF
chmod +x /usr/local/bin/unblock-wifi-rfkill.sh
/usr/local/bin/unblock-wifi-rfkill.sh

cat << 'EOF' > /usr/local/bin/prepare-standard-mesh-iface.sh
#!/bin/sh
set -u

IFACE="${1:-}"
[ -n "$IFACE" ] || exit 0
[ -e "/sys/class/net/$IFACE" ] || exit 0

/usr/local/bin/unblock-wifi-rfkill.sh 2>/dev/null || true

driver="$(basename "$(readlink -f "/sys/class/net/$IFACE/device/driver" 2>/dev/null)")"
if [ -z "$driver" ] || [ "$driver" = "." ]; then
    driver="$(ethtool -i "$IFACE" 2>/dev/null | awk -F': ' '$1 == "driver" {print $2; exit}')"
fi

case "$driver" in
    brcmfmac|morse*)
        exit 0
        ;;
esac

# Do not force mesh point mode if this interface is the designated AP
AP_IF="$(cat /var/lib/ap_interface 2>/dev/null)"
if [ -n "$AP_IF" ] && [ "$IFACE" = "$AP_IF" ]; then
    exit 0
fi

iw dev "$IFACE" info 2>/dev/null | grep -q 'type mesh point' && exit 0

ip link set "$IFACE" down 2>/dev/null || true
sleep 1
iw dev "$IFACE" set type mp 2>/dev/null || true
sleep 1

if ! iw dev "$IFACE" info 2>/dev/null | grep -q 'type mesh point'; then
    echo "Warning: $IFACE did not enter mesh point mode before wpa_supplicant" >&2
fi
EOF
chmod +x /usr/local/bin/prepare-standard-mesh-iface.sh

cat << EOF > /etc/systemd/system/wifi-rfkill-unblock.service
[Unit]
Description=Unblock Wi-Fi rfkill switches
Before=hostapd.service batman-enslave.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/unblock-wifi-rfkill.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

# A system service to force mesh point mode on the wlan interfaces
cat << EOF > /etc/systemd/system/mesh-interface-setup@.service
[Unit]
Description=Set %I to mesh point mode
Before=wpa_supplicant@%i.service
BindsTo=sys-subsystem-net-devices-%i.device
After=sys-subsystem-net-devices-%i.device

[Service]
Type=oneshot
ExecStartPre=/usr/local/bin/unblock-wifi-rfkill.sh
ExecStartPre=/bin/sleep 1
ExecStart=/usr/local/bin/prepare-standard-mesh-iface.sh %I
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

mkdir -p /etc/systemd/system/wpa_supplicant@.service.d
cat << EOF > /etc/systemd/system/wpa_supplicant@.service.d/10-mesh-prep.conf
[Unit]
After=wifi-rfkill-unblock.service
Wants=wifi-rfkill-unblock.service

[Service]
ExecStartPre=/usr/local/bin/unblock-wifi-rfkill.sh
ExecStartPre=/usr/local/bin/prepare-standard-mesh-iface.sh %i
EOF

REGULATORY_DOMAIN=$(grep "^regulatory_domain=" /etc/mesh.conf 2>/dev/null | cut -d'=' -f2)
REGULATORY_DOMAIN=${REGULATORY_DOMAIN:-US}  # Default to US if not found
HALOW_REGULATORY_DOMAIN=$(grep "^halow_regulatory_domain=" /etc/mesh.conf 2>/dev/null | cut -d'=' -f2)
HALOW_REGULATORY_DOMAIN=${HALOW_REGULATORY_DOMAIN:-$REGULATORY_DOMAIN}
REG=$REGULATORY_DOMAIN

echo REGDOMAIN=$REGULATORY_DOMAIN > /etc/default/crda

uses_eu_halow_region() {
    local domain="$1"

    case "$domain" in
        AT|BE|BG|HR|CY|CZ|DK|EE|FI|FR|DE|GR|HU|IE|IT|LV|LT|LU|MT|NL|PL|PT|RO|SK|SI|ES|SE|GB|CH|NO)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

if [ -z "$HALOW_REGULATORY_DOMAIN" ] || uses_eu_halow_region "$REGULATORY_DOMAIN"; then
    HALOW_REGULATORY_DOMAIN="EU"
fi

# cfg80211 regdomain for the 2.4/5 GHz (mt7915) radios — use the real ISO
# country code (e.g. HR). The Morse HaLow phy is self-managed and applies
# HALOW_REGULATORY_DOMAIN (EU) on its own via the morse module param, so
# cfg80211 must NOT be forced to "EU": that is a synthetic DFS-invalid regdb
# entry that cfg80211 rejects, leaving the global regdom stuck at WORLD/00.
CFG80211_REGDOM="$REGULATORY_DOMAIN"


# Wait for wireless drivers to load
echo "Waiting for wireless drivers to load..."
DRIVER_WAIT_COUNT=0
MAX_DRIVER_WAIT=30  # 60 seconds total

while [ $DRIVER_WAIT_COUNT -lt $MAX_DRIVER_WAIT ]; do
    PHY_COUNT=$(iw dev 2>/dev/null | grep -c "^phy#")

    if [ "$PHY_COUNT" -gt 0 ]; then
        echo "✓ Found $PHY_COUNT wireless PHY(s)"
        break
    fi

    if [ $DRIVER_WAIT_COUNT -eq 0 ]; then
        echo "No wireless interfaces detected yet, waiting for drivers..."
    elif [ $((DRIVER_WAIT_COUNT % 5)) -eq 0 ]; then
        echo "Still waiting... (${DRIVER_WAIT_COUNT}/${MAX_DRIVER_WAIT})"
    fi

    sleep 2
    ((DRIVER_WAIT_COUNT++))
done

if [ "$PHY_COUNT" -eq 0 ]; then
    echo "⚠ WARNING: No wireless interfaces found after $((MAX_DRIVER_WAIT * 2)) seconds"
    echo "  This is normal for wired-only configurations"
    echo "  If you expect wireless: check 'dmesg | grep -i firmware'"
fi

# ============================================================================
# === INTERFACE DETECTION ===
# ============================================================================

# Detect interfaces, classify by type
mesh_ifaces=()
halow_ifaces=()
nonmesh_ifaces=()

iface_driver() {
    local iface="$1"
    local driver

    driver="$(basename "$(readlink -f /sys/class/net/$iface/device/driver 2>/dev/null)")"
    if [[ -z "$driver" || "$driver" == "." ]]; then
        driver="$(ethtool -i "$iface" 2>/dev/null | awk -F': ' '$1 == "driver" {print $2; exit}')"
    fi

    echo "$driver"
}

is_halow_iface() {
    local iface="$1"
    local driver phyname

    driver="$(iface_driver "$iface")"
    [[ "$driver" == morse* ]] && return 0

    # Fallback: USB HaLow adapters may report a USB driver name instead of
    # morse via sysfs.  A wireless phy with no standard 2.4/5 GHz frequencies
    # is a sub-GHz (HaLow) device.
    phyname="$(iface_phy "$iface")"
    [[ -z "$phyname" ]] && return 1

    if ! iw phy "$phyname" info 2>/dev/null | grep -q "2412\.0 MHz" && \
       ! iw phy "$phyname" info 2>/dev/null | grep -q "5180\.0 MHz"; then
        return 0
    fi

    return 1
}

is_nonmesh_wifi() {
    local iface="$1"
    local driver

    driver="$(iface_driver "$iface")"

    # Raspberry Pi onboard Wi-Fi advertises mesh point support in some kernels,
    # but on this platform it is reserved for the EUD AP/hotspot. Keep it out
    # of mesh_if so rerunning setup cannot enslave the AP radio to bat0.
    [[ "$driver" == brcmfmac ]]
}

iface_phy() {
    local iface="$1"
    iw dev "$iface" info 2>/dev/null | awk '/wiphy/ {print "phy"$2; exit}'
}

iface_supports_mesh() {
    local iface="$1"
    local phyname

    phyname="$(iface_phy "$iface")"
    [[ -n "$phyname" ]] && iw phy "$phyname" info 2>/dev/null | grep -q "mesh point"
}

iface_supports_freq() {
    local iface="$1"
    local freq="$2"
    local phyname
    phyname="$(iface_phy "$iface")"
    [[ -n "$phyname" ]] && iw phy "$phyname" info 2>/dev/null | grep -q "${freq}\\.0 MHz"
}

iface_mesh_freq() {
    local iface="$1"
    local phyname
    phyname="$(iface_phy "$iface")"
    [[ -z "$phyname" ]] && echo "" && return

    if iw phy "$phyname" info 2>/dev/null | grep -q "2412\\.0 MHz"; then
        echo "2412"
    elif iw phy "$phyname" info 2>/dev/null | grep -q "5180\\.0 MHz"; then
        echo "5180"
    else
        echo ""
    fi
}

for iface in $(iw dev | awk '$1 == "Interface" {print $2}'); do
    if is_halow_iface "$iface"; then
        halow_ifaces+=("$iface")
    elif is_nonmesh_wifi "$iface"; then
        nonmesh_ifaces+=("$iface")
    elif iface_supports_mesh "$iface"; then
        mesh_ifaces+=("$iface")
    else
        nonmesh_ifaces+=("$iface")
    fi
done

# Order standard mesh interfaces by role, not by volatile wlanX name. The first
# interface receives the 2.4 GHz lobby config and the second receives the 5 GHz
# lobby config. Prefer single-band matches when possible, then fall back to any
# device supporting the required lobby frequency.
if [ "${#mesh_ifaces[@]}" -gt 1 ]; then
    mesh_24=""
    mesh_5=""

    for iface in "${mesh_ifaces[@]}"; do
        if iface_supports_freq "$iface" 2412 && ! iface_supports_freq "$iface" 5180; then
            mesh_24="$iface"
            break
        fi
    done
    for iface in "${mesh_ifaces[@]}"; do
        if iface_supports_freq "$iface" 5180 && ! iface_supports_freq "$iface" 2412; then
            mesh_5="$iface"
            break
        fi
    done
    [ -z "$mesh_24" ] && for iface in "${mesh_ifaces[@]}"; do
        iface_supports_freq "$iface" 2412 && mesh_24="$iface" && break
    done
    [ -z "$mesh_5" ] && for iface in "${mesh_ifaces[@]}"; do
        [ "$iface" = "$mesh_24" ] && continue
        iface_supports_freq "$iface" 5180 && mesh_5="$iface" && break
    done

    reordered=()
    [ -n "$mesh_24" ] && reordered+=("$mesh_24")
    [ -n "$mesh_5" ] && reordered+=("$mesh_5")
    for iface in "${mesh_ifaces[@]}"; do
        [ "$iface" = "$mesh_24" ] && continue
        [ "$iface" = "$mesh_5" ] && continue
        reordered+=("$iface")
    done
    mesh_ifaces=("${reordered[@]}")
elif [ "${#mesh_ifaces[@]}" -eq 1 ]; then
    mapfile -t mesh_ifaces < <(printf '%s\n' "${mesh_ifaces[@]}" | sort -V)
fi

# Create directory and files (supports wired-only configs if arrays are empty)
mkdir -p /var/lib
> /var/lib/mesh_if
> /var/lib/mesh_24_if
> /var/lib/mesh_5_if
> /var/lib/halow_if
> /var/lib/no_mesh_if
> /var/lib/iface_map   # runtime_name:physical_name (for MAC lookups during provisioning)

# Persist the runtime interface names. The rest of the setup and boot scripts
# consume these files as live netdev names, so writing desired logical names
# before udev has renamed anything can make HaLow and non-mesh devices appear
# swapped. Keep iface_map as an identity map for phys_iface() callers.
for iface in "${mesh_ifaces[@]}"; do
    echo "$iface" >> /var/lib/mesh_if
    echo "$iface:$iface" >> /var/lib/iface_map
    echo " > Mapped $iface (mesh)"
done
[ "${#mesh_ifaces[@]}" -gt 0 ] && echo "${mesh_ifaces[0]}" > /var/lib/mesh_24_if
[ "${#mesh_ifaces[@]}" -gt 1 ] && echo "${mesh_ifaces[1]}" > /var/lib/mesh_5_if
for iface in "${halow_ifaces[@]}"; do
    echo "$iface" >> /var/lib/halow_if
    echo "$iface:$iface" >> /var/lib/iface_map
    echo " > Mapped $iface (HaLow)"
done
for iface in "${nonmesh_ifaces[@]}"; do
    echo "$iface" >> /var/lib/no_mesh_if
    echo "$iface:$iface" >> /var/lib/iface_map
    echo " > Mapped $iface (non-mesh)"
done

# Log what we found
echo "Interface detection complete:"
echo "  Mesh-capable: ${#mesh_ifaces[@]} (${mesh_ifaces[*]})"
echo "  Mesh 2.4 role: $(cat /var/lib/mesh_24_if 2>/dev/null || true)"
echo "  Mesh 5.0 role: $(cat /var/lib/mesh_5_if 2>/dev/null || true)"
echo "  HaLow: ${#halow_ifaces[@]} (${halow_ifaces[*]})"
echo "  Non-mesh: ${#nonmesh_ifaces[@]} (${nonmesh_ifaces[*]})"
echo "  Logical mapping:"
cat /var/lib/iface_map

# ============================================================================
# === AP INTERFACE SELECTION (for wireless/auto EUD modes) ===
# ============================================================================

AP_INTERFACE=""

if [[ "$eud" == "wireless" ]] || [[ "$eud" == "auto" ]]; then
    echo "EUD mode is $eud - selecting AP interface..."

    # Priority 1: Use non-mesh interface if available (RPi 5 onboard)
    if [ -s /var/lib/no_mesh_if ]; then
        AP_INTERFACE=$(head -1 /var/lib/no_mesh_if)
        echo " > Using non-mesh interface for AP: $AP_INTERFACE"

    # Priority 2: Find 5GHz-capable interface from mesh interfaces
    elif [ -s /var/lib/mesh_if ]; then
        echo " > Searching for 5GHz-capable mesh interface..."
        for iface in $(cat /var/lib/mesh_if); do
            PHY=$(iw dev "$iface" info | grep wiphy | awk '{print "phy" $2}')
            if iw phy "$PHY" info 2>/dev/null | grep " 5[0-9][0-9][0-9]" >/dev/null; then
                AP_INTERFACE="$iface"
                echo " > Found 5GHz-capable interface: $AP_INTERFACE"
                break
            fi
        done

        if [ -z "$AP_INTERFACE" ]; then
            echo "WARNING: No 5GHz-capable interface found. Using first mesh interface."
            AP_INTERFACE=$(head -1 /var/lib/mesh_if)
        fi
    else
        echo "ERROR: No suitable interface found for AP!"
        AP_INTERFACE=""
    fi

    # Save AP interface selection and remove it from mesh_if so batman-enslave
    # doesn't try to enslave it (which would make it unavailable for hostapd).
    if [ -n "$AP_INTERFACE" ]; then
        echo "$AP_INTERFACE" > /var/lib/ap_interface
        echo "AP interface selected: $AP_INTERFACE"
        sed -i "/^${AP_INTERFACE}$/d" /var/lib/mesh_if
        if [ "$(cat /var/lib/mesh_5_if 2>/dev/null)" = "$AP_INTERFACE" ]; then
            > /var/lib/mesh_5_if
        fi
        echo " > Removed $AP_INTERFACE from mesh_if (reserved for AP)"
    fi
fi

# ============================================================================
# === CLEANUP STALE PER-INTERFACE SERVICES AND CONFIGS ===
# ============================================================================
# Previous runs may have enabled wpa_supplicant or s1g services for interfaces
# that no longer hold those roles (e.g. after a .link rename swapped which
# physical card is wlanX). Disable any per-interface service whose target
# interface isn't currently classified for that role.

current_mesh="$(cat /var/lib/mesh_if 2>/dev/null | tr '\n' ' ')"
current_halow="$(cat /var/lib/halow_if 2>/dev/null | tr '\n' ' ')"

cleanup_iface_service() {
    local svc_pattern="$1"   # e.g. "wpa_supplicant@wlan*.service"
    local valid_list="$2"    # space-separated interface names that should keep this service
    local svc iface link

    # Find enabled units by looking at symlinks in target wants directories.
    # This catches both concrete units and instantiated template units.
    for link in /etc/systemd/system/*.wants/$svc_pattern \
                /etc/systemd/system/*.requires/$svc_pattern; do
        [ -L "$link" ] || continue
        svc="$(basename "$link")"

        iface="$(echo "$svc" | sed -E 's/.*[@-](wlan[0-9]+)\.service$/\1/')"
        [[ "$iface" == "$svc" ]] && continue

        if ! echo " $valid_list " | grep -q " $iface "; then
            echo " > Disabling stale service: $svc (iface $iface no longer in role)"
            systemctl disable --now "$svc" 2>/dev/null || true
            systemctl reset-failed "$svc" 2>/dev/null || true
        fi
    done

    # Also catch units that are loaded/failed but never had an enable symlink
    # (e.g. started manually, or left over after their wants symlink was removed
    # but the runtime instance kept lingering).
    for svc in $(systemctl list-units --all --no-legend --state=failed,loaded "$svc_pattern" 2>/dev/null | awk '{print $1}'); do
        iface="$(echo "$svc" | sed -E 's/.*[@-](wlan[0-9]+)\.service$/\1/')"
        [[ "$iface" == "$svc" ]] && continue

        if ! echo " $valid_list " | grep -q " $iface "; then
            echo " > Cleaning up stale runtime instance: $svc"
            systemctl stop "$svc" 2>/dev/null || true
            systemctl reset-failed "$svc" 2>/dev/null || true
        fi
    done
}

cleanup_iface_service 'wpa_supplicant@wlan*.service' "$current_mesh"
cleanup_iface_service 'wpa_supplicant-s1g-wlan*.service' "$current_halow"
cleanup_iface_service 'halow-txpower-wlan*.service' "$current_halow"

# Remove stale per-interface wpa_supplicant config files for interfaces that
# don't currently hold a wireless role. mesh-boot-lobby.service blindly copies
# every *-lobby.conf at boot, so leftovers will resurrect dead configs.
all_wireless_roles="$current_mesh $current_halow"
for conf in /etc/wpa_supplicant/wpa_supplicant-wlan*.conf; do
    [ -e "$conf" ] || continue
    iface="$(basename "$conf" | sed -E 's/^wpa_supplicant-(wlan[0-9]+).*/\1/')"
    if ! echo " $all_wireless_roles " | grep -q " $iface "; then
        echo " > Removing stale wpa_supplicant config: $conf"
        rm -f "$conf"
    fi
done

# ============================================================================
# === CONFIGURE MESH INTERFACES (excluding AP if needed) ===
# ============================================================================

# Pin wlanX names by MAC so role assignments survive reboot in a predictable
# order: wlan0=2.4GHz mesh, wlan1=5GHz mesh, wlan2=HaLow, wlan3=non-mesh AP.
# The classification above already determined which physical phy plays which
# role; we now bind that role to a stable MAC-keyed name via systemd .link.
# These take effect at next boot — current run uses kernel-assigned names from
# the role files.
rm -f /etc/systemd/network/10-wlan*.link

iface_mac() {
    cat "/sys/class/net/$1/address" 2>/dev/null
}

write_link_file() {
    local target_name="$1"
    local mac="$2"
    [[ -z "$mac" ]] && return

cat <<-EOF > /etc/systemd/network/10-${target_name}.link
[Match]
MACAddress=$mac
Type=wlan

[Link]
Name=$target_name
EOF
    echo " > Pinning $target_name to MAC $mac"
}

# Mesh interfaces are already ordered: [0]=2.4GHz, [1]=5GHz
[ "${#mesh_ifaces[@]}" -gt 0 ] && write_link_file wlan0 "$(iface_mac "${mesh_ifaces[0]}")"
[ "${#mesh_ifaces[@]}" -gt 1 ] && write_link_file wlan1 "$(iface_mac "${mesh_ifaces[1]}")"
[ "${#halow_ifaces[@]}" -gt 0 ] && write_link_file wlan2 "$(iface_mac "${halow_ifaces[0]}")"
[ "${#nonmesh_ifaces[@]}" -gt 0 ] && write_link_file wlan3 "$(iface_mac "${nonmesh_ifaces[0]}")"
echo "MESH_NAME=\"$MESH_NAME\"" > /etc/default/mesh


# Detect if the .link files we just wrote disagree with current runtime names.
# If they do, the next boot will rename interfaces and the role files we wrote
# this run will be stale. Schedule a post-reboot re-run to refresh them.
needs_rerun=0
check_rename() {
    local target="$1"
    local current="$2"
    [[ -z "$current" ]] && return
    [[ "$target" == "$current" ]] && return
    echo " > Rename pending: $current -> $target (next boot)"
    needs_rerun=1
}

[ "${#mesh_ifaces[@]}" -gt 0 ] && check_rename wlan0 "${mesh_ifaces[0]}"
[ "${#mesh_ifaces[@]}" -gt 1 ] && check_rename wlan1 "${mesh_ifaces[1]}"
[ "${#halow_ifaces[@]}" -gt 0 ] && check_rename wlan2 "${halow_ifaces[0]}"
[ "${#nonmesh_ifaces[@]}" -gt 0 ] && check_rename wlan3 "${nonmesh_ifaces[0]}"

if [ "$needs_rerun" -eq 1 ]; then
    echo " > Interface renames staged. Scheduling post-reboot re-run."

cat << 'EOF' > /etc/systemd/system/radio-setup-rerun.service
[Unit]
Description=Re-run radio-setup after interface rename
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/radio-setup.sh
ExecStartPost=/bin/systemctl disable radio-setup-rerun.service
ExecStartPost=/bin/rm -f /etc/systemd/system/radio-setup-rerun.service
RemainAfterExit=no

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable radio-setup-rerun.service
    touch /var/lib/radio-setup-reboot-pending
else
    echo " > Interface names already match desired layout, no rename needed"
fi

# Mesh (SAE) supplicant config for one interface. Used for the mesh interfaces
# below, and for the AP interface, which needs a config on disk even though its
# service stays disabled - ethernet-autodetect restarts wpa_supplicant@<ap
# iface> when a wired EUD returns that radio to the mesh, and without this file
# that service just fails.
write_mesh_wpa_conf() {
    local iface="$1" freq="$2"
cat <<-EOF > /etc/wpa_supplicant/wpa_supplicant-$iface-lobby.conf
ctrl_interface=/var/run/wpa_supplicant
country=$CFG80211_REGDOM
update_config=1
sae_pwe=1
ap_scan=2
network={
    ssid="$MESH_NAME"
    mode=5
    frequency=${freq}
    key_mgmt=SAE
    sae_password="$KEY"
    ieee80211w=2
    mesh_fwding=0
    group_rekey=0
}
EOF
    cp /etc/wpa_supplicant/wpa_supplicant-$iface-lobby.conf \
       /etc/wpa_supplicant/wpa_supplicant-$iface.conf
}

for WLAN in $(cat /var/lib/mesh_if); do
    # If interface renames are pending the names we have now are the pre-rename
    # names. Skip config writes; the post-reboot re-run will write them with
    # the correct names.
    if [ "$needs_rerun" -eq 1 ]; then
        echo " > Rename pending — deferring wpa config for $WLAN to post-reboot re-run"
        continue
    fi

    # Skip this interface if it's the AP interface
    if [[ -n "$AP_INTERFACE" ]] && [[ "$WLAN" == "$AP_INTERFACE" ]]; then
        echo " > Skipping $WLAN (will be used as AP)"
        continue
    fi

    FREQ=$(iface_mesh_freq "$WLAN")
    if [[ -z "$FREQ" ]]; then
        echo " > WARNING: Cannot determine band for $WLAN, skipping"
        continue
    fi

    echo " > Setting SAE key/SSID for $WLAN (${FREQ} MHz) ..."
    write_mesh_wpa_conf "$WLAN" "$FREQ"

    # Create the network interface config
cat <<-EOF > /etc/systemd/network/30-$WLAN.network
[Match]
MACAddress=$(ip a | grep -A1 "$(phys_iface $WLAN)" | awk '/ether/ {print $2}')

[Network]

[Link]
RequiredForOnline=no
MTUBytes=1532
EOF

    echo " > Enabling $WLAN for mesh use ..."
    systemctl enable wpa_supplicant@$WLAN.service
done

# ============================================================================
# === CONFIGURE AP INTERFACE (if wireless/auto mode) ===
# ============================================================================

HOST_MAC=$(ip a | grep -A1 $(networkctl | grep -v bat | awk '/ether/ {print $2}' | head -1) \
   | awk '/ether/ {print $2}' | cut -d':' -f 5-6 | sed 's/://g')

if [[ -n "$AP_INTERFACE" ]] && [ "$needs_rerun" -eq 1 ]; then
    echo " > Rename pending - deferring AP config to post-reboot re-run"
elif [[ -n "$AP_INTERFACE" ]]; then
    echo "Configuring $AP_INTERFACE as access point..."

    # The AP radio also needs a mesh config on disk: in wired-EUD mode
    # ethernet-autodetect hands it back to the mesh and restarts
    # wpa_supplicant@$AP_INTERFACE. The service stays disabled - only that
    # path starts it.
    AP_MESH_FREQ=$(iface_mesh_freq "$AP_INTERFACE")
    if [[ -n "$AP_MESH_FREQ" ]]; then
        echo " > Writing mesh config for $AP_INTERFACE (${AP_MESH_FREQ} MHz, service left disabled)"
        write_mesh_wpa_conf "$AP_INTERFACE" "$AP_MESH_FREQ"
    else
        echo " > WARNING: cannot determine mesh band for $AP_INTERFACE, no mesh config written"
    fi

cat <<-EOF > /etc/systemd/system/ap-interface-setup.service
[Unit]
Description=Set $AP_INTERFACE to managed mode for hostapd
Before=hostapd.service
After=wifi-rfkill-unblock.service wpa_supplicant@${AP_INTERFACE}.service
Wants=wifi-rfkill-unblock.service

[Service]
Type=oneshot
# Do nothing if hostapd already has the radio. Before= only orders units
# queued in one transaction, and ethernet-autodetect starts hostapd from a
# carrier event outside it - so this unit can land after the AP is live, and
# downing the interface here leaves hostapd active with a dead BSS that
# nothing brings back.
ExecCondition=/bin/sh -c '! ( systemctl is-active --quiet hostapd.service && /usr/sbin/iw dev $AP_INTERFACE info 2>/dev/null | grep -q "type AP" )'
ExecStartPre=/usr/local/bin/unblock-wifi-rfkill.sh
ExecStartPre=/bin/sleep 2
ExecStartPre=-/bin/systemctl stop wpa_supplicant@${AP_INTERFACE}.service
ExecStart=-/usr/sbin/ip link set $AP_INTERFACE down
ExecStart=-/usr/sbin/iw dev $AP_INTERFACE set type managed
ExecStart=-/usr/sbin/ip link set $AP_INTERFACE up
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    # Create networkd config for AP interface (unmanaged, hostapd will control it)
    cat <<-EOF > /etc/systemd/network/30-${AP_INTERFACE}.network
[Match]
Name=$AP_INTERFACE

[Link]
Unmanaged=yes
ActivationPolicy=manual
EOF

    # Get configuration from mesh.conf
    while IFS= read -r line; do
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
        key="${line%%=*}"
        value="${line#*=}"
        case "$key" in
            lan_ap_ssid) LAN_AP_SSID="$value" ;;
            lan_ap_key) LAN_AP_KEY="$value" ;;
            max_euds_per_node) MAX_EUDS="$value" ;;
            ipv4_network) IPV4_NETWORK="$value" ;;
        esac
    done < /etc/mesh.conf

    # Calculate DHCP pool based on max EUDs
    CALC_OUTPUT=$(manet-ipcalc.sh "$IPV4_NETWORK" 2>/dev/null)
    FIRST_IP=$(echo "$CALC_OUTPUT" | awk '/HostMin/ {print $2}')

    # Start pool at IP 6
    DHCP_START="${FIRST_IP%.*}.$((${FIRST_IP##*.} + 5))"

    PREFIX=$(echo "$IPV4_NETWORK" | cut -d'/' -f2)
    HOST_BITS=$((32 - PREFIX))
    TOTAL_IPS=$((2**HOST_BITS - 2))
    MAX_NODES=$((TOTAL_IPS / (1 + MAX_EUDS)))
    POOL_SIZE=$((MAX_NODES * MAX_EUDS))

    POOL_END_OFFSET=$((5 + POOL_SIZE - 1))
    DHCP_END="${FIRST_IP%.*}.$((${FIRST_IP##*.} + POOL_END_OFFSET))"

    echo " > DHCP pool: $DHCP_START - $DHCP_END (${POOL_SIZE} IPs for ${MAX_EUDS} EUDs × ${MAX_NODES} nodes)"

    # Detect 5 GHz capability to pick the right hw_mode and default channel
    if iface_supports_freq "$AP_INTERFACE" 5180; then
        AP_HW_MODE="a"
        AP_CHANNEL="${lan_ap_channel:-36}"
        AP_80211AC="ieee80211ac=1"
    else
        AP_HW_MODE="g"
        AP_CHANNEL="${lan_ap_channel:-11}"
        AP_80211AC=""
    fi

    cat <<-EOF > /etc/hostapd/hostapd.conf
interface=$AP_INTERFACE
bridge=br0
driver=nl80211
ssid=${LAN_AP_SSID}-${HOST_MAC}
country_code=$REGULATORY_DOMAIN
ieee80211d=1

# hw_mode=a for 5 GHz interfaces, hw_mode=g for 2.4 GHz
hw_mode=$AP_HW_MODE
channel=$AP_CHANNEL
ieee80211n=1
$AP_80211AC
wmm_enabled=1

# WPA2 security
auth_algs=1
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
wpa_passphrase=$LAN_AP_KEY
EOF

cat <<-EOF > /etc/systemd/system/ap-txpower.service
[Unit]
Description=Set low TX power on AP interface
After=ap-interface-setup.service
Wants=ap-interface-setup.service

[Service]
Type=oneshot
ExecStartPre=/bin/sleep 2
# mt7915e ignores per-netdev txpower in AP mode; must set on the wiphy.
ExecStart=-/bin/sh -c '/usr/sbin/iw phy "\$(cat /sys/class/net/$AP_INTERFACE/phy80211/name)" set txpower fixed 500'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    # Enable proxy ARP on br0 for EUD routing
    cat <<-EOF >> /etc/sysctl.d/99-mesh.conf

# Proxy ARP for EUD clients
net.ipv4.conf.br0.proxy_arp=1
EOF
    sysctl -p /etc/sysctl.d/99-mesh.conf

    systemctl enable ap-txpower.service
    systemctl unmask dnsmasq.service
    systemctl enable dnsmasq.service

    if [[ "$eud" == "wireless" ]]; then
        echo " > Wireless mode: Enabling and starting AP services"
        systemctl unmask hostapd.service
        systemctl enable ap-interface-setup.service
        systemctl enable hostapd.service
        systemctl restart ap-interface-setup.service 2>/dev/null || true
        systemctl restart hostapd.service 2>/dev/null || true
        systemctl restart dnsmasq.service 2>/dev/null || true
        systemctl restart ap-txpower.service 2>/dev/null || true
    else
        systemctl unmask hostapd.service
        echo " > Auto mode: AP services staged (ethernet-autodetect will manage)"
        systemctl disable hostapd.service
        # A hostapd started before this run holds the interface its old config
        # named. After the first-boot rename that name can belong to a
        # different radio - on the bench CM4s it was the HaLow one - and
        # nothing here would ever move it. Only restart a daemon that is
        # already up; whether the AP runs at all in auto mode stays
        # ethernet-autodetect's decision.
        if systemctl is-active --quiet hostapd.service; then
            echo " > Restarting running hostapd onto $AP_INTERFACE"
            systemctl restart hostapd.service 2>/dev/null || true
        fi
    fi

    echo "AP configuration complete for $AP_INTERFACE"
fi

# ============================================================================
# === CONFIGURE CLIENT AP (if exists and not used for mesh AP) ===
# ============================================================================

for WLAN in $(cat /var/lib/no_mesh_if | head -n 1); do
    # Skip if this is already the AP interface
    if [[ -n "$AP_INTERFACE" ]] && [[ "$WLAN" == "$AP_INTERFACE" ]]; then
        continue
    fi

    echo " > Setting up $WLAN as a client AP ..."
    echo "   > creating networkd file ..."

cat <<- EOF > /etc/systemd/network/30-$WLAN.network
[Match]
Name=$WLAN

[Link]
Unmanaged=yes
ActivationPolicy=manual
EOF

    systemctl enable mesh-interface-setup@$WLAN
done

# ============================================================================
# === HALOW CONFIGURATION ===
# ============================================================================

for WLAN in $(cat /var/lib/halow_if | head -n 1); do
    if [ "$needs_rerun" -eq 1 ]; then
        echo " > Rename pending — deferring HaLow wpa config for $WLAN to post-reboot re-run"
        continue
    fi

    echo " > Setting up $WLAN for HaLow use ..."

    # Create the network interface config
cat <<-EOF > /etc/systemd/network/30-$WLAN.network
[Match]
MACAddress=$(ip a | grep -A1 "$(phys_iface $WLAN)" | awk '/ether/ {print $2}')

[Network]

[Link]
RequiredForOnline=no
MTUBytes=1532
EOF

    rm -f /etc/wpa_supplicant/*${WLAN}* 2>/dev/null

    if [[ "$HALOW_REGULATORY_DOMAIN" == "US" ]]; then
cat << EOF > /etc/wpa_supplicant/wpa_supplicant-$WLAN-s1g.conf
country="US"
ctrl_interface=/var/run/wpa_supplicant_s1g
sae_pwe=1
max_peer_links=10
mesh_fwding=0
network={
    ssid="$mesh_ssid"
    key_mgmt=SAE
    mode=5
    channel=12
    op_class=71
    country="US"
    s1g_prim_chwidth=1
    s1g_prim_1mhz_chan_index=3
    dtim_period=1
    mesh_rssi_threshold=-85
    dot11MeshHWMPRootMode=0
    dot11MeshGateAnnouncements=0
    mbca_config=1
    mbca_min_beacon_gap_ms=25
    mbca_tbtt_adj_interval_sec=60
    dot11MeshBeaconTimingReportInterval=10
    mbss_start_scan_duration_ms=2048
    mesh_beaconless_mode=0
    mesh_dynamic_peering=0
    sae_password="$mesh_key"
    pairwise=CCMP
    ieee80211w=2
    beacon_int=1000
    group_rekey=0
}
EOF
    else
cat << EOF > /etc/wpa_supplicant/wpa_supplicant-$WLAN-s1g.conf
country="$HALOW_REGULATORY_DOMAIN"
ctrl_interface=/var/run/wpa_supplicant_s1g
sae_pwe=1
max_peer_links=10
mesh_fwding=0
network={
    ssid="$mesh_ssid"
    key_mgmt=SAE
    mode=5
    channel=1
    op_class=66
    country="$HALOW_REGULATORY_DOMAIN"
    s1g_prim_chwidth=0
    s1g_prim_1mhz_chan_index=0
    dtim_period=1
    mesh_rssi_threshold=-85
    dot11MeshHWMPRootMode=0
    dot11MeshGateAnnouncements=0
    mbca_config=0
    mbca_min_beacon_gap_ms=25
    mbca_tbtt_adj_interval_sec=60
    dot11MeshBeaconTimingReportInterval=10
    mbss_start_scan_duration_ms=2048
    mesh_beaconless_mode=0
    mesh_dynamic_peering=0
    sae_password="$mesh_key"
    pairwise=CCMP
    ieee80211w=2
    beacon_int=100
    group_rekey=0
}
EOF
    fi

    # Set HaLow TX power to 24 dBm (2400 mBm) after interface comes up
cat << EOF > /etc/systemd/system/halow-txpower-$WLAN.service
[Unit]
Description=Set HaLow TX power for $WLAN
After=wpa_supplicant-s1g-$WLAN.service
Wants=wpa_supplicant-s1g-$WLAN.service

[Service]
Type=oneshot
ExecStartPre=/bin/sleep 5
ExecStart=/usr/sbin/iw dev $WLAN set txpower fixed 2400
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
    systemctl enable halow-txpower-$WLAN.service

cat << EOF > /etc/systemd/system/wpa_supplicant-s1g-$WLAN.service
[Unit]
Description=WPA supplicant (S1G/HaLow) for $WLAN
After=sys-subsystem-net-devices-${WLAN}.device
Requires=sys-subsystem-net-devices-${WLAN}.device

[Service]
Type=simple
ExecStartPre=/usr/local/bin/unblock-wifi-rfkill.sh
ExecStartPre=/bin/sleep 3
ExecStart=/usr/sbin/wpa_supplicant_s1g -c /etc/wpa_supplicant/wpa_supplicant-$WLAN-s1g.conf -i $WLAN -D nl80211
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

    systemctl disable wpa_supplicant_s1g@$WLAN.service 2>/dev/null || true
    systemctl enable wpa_supplicant-s1g-$WLAN.service

done

# ============================================================================
# === MORSE / HALOW MODULE OPTIONS ===
# ============================================================================
echo "options cfg80211 ieee80211_regdom=$CFG80211_REGDOM" > /etc/modprobe.d/cfg80211.conf

# Preserve hardware-specific SPI modprobe options that were written by firstrun.
# USB MM81xx adapters auto-select BCF by board type; forcing SPI BCF breaks probe.
MORSE_BCF=""
MORSE_SPI_CLOCK=""
if [ -f /etc/modprobe.d/morse.conf ] && ! has_usb_morse_device; then
    MORSE_BCF=$(grep -oP '(?<=bcf=)\S+' /etc/modprobe.d/morse.conf | head -1)
    MORSE_SPI_CLOCK=$(grep -oP '(?<=spi_clock_speed=)\S+' /etc/modprobe.d/morse.conf | head -1)
fi

echo "options morse enable_mcast_whitelist=0 enable_mcast_rate_control=1" > /etc/modprobe.d/morse.conf
echo "options morse country=$HALOW_REGULATORY_DOMAIN" >> /etc/modprobe.d/morse.conf

[[ -n "$MORSE_BCF" ]]       && echo "options morse bcf=$MORSE_BCF" >> /etc/modprobe.d/morse.conf
[[ -n "$MORSE_SPI_CLOCK" ]] && echo "options morse spi_clock_speed=$MORSE_SPI_CLOCK" >> /etc/modprobe.d/morse.conf


if [[ "$HALOW_REGULATORY_DOMAIN" == "EU" ]]; then
    echo "options morse enable_auto_duty_cycle=0 enable_auto_mpsw=0" >> /etc/modprobe.d/morse.conf
fi

# ============================================================================
# === SYSTEM SERVICE SETUP ===
# ============================================================================

# Watch for button presses
cat << EOF > /etc/systemd/system/led-boot.service
[Unit]
Description=LED boot
After=sysinit.target
DefaultDependencies=no

[Service]
Type=oneshot
RemainAfterExit=no
ExecStart=/usr/local/bin/led-boot.sh
TimeoutStartSec=infinity

[Install]
WantedBy=sysinit.target
EOF
systemctl enable led-boot.service
systemctl enable wifi-rfkill-unblock.service

cat << EOF > /etc/systemd/system/button-monitor.service
[Unit]
Description=Button monitor - launches LED info on press
After=multi-user.target

[Service]
Type=simple
ExecStart=/usr/local/bin/button-monitor.sh
# on-failure (not always): the script exits 0 when the GPIO chip is absent,
# and that must stay exited instead of relaunching every second.
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl enable button-monitor.service

cat << EOF > /etc/systemd/system/mesh-clone-identity.service
[Unit]
Description=Reset cloned mesh node identity when hardware MAC changes
After=local-fs.target
Before=batman-enslave.service alfred.service node-manager.service gateway-route-manager.service syncthing@radio.service hostapd.service dnsmasq.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/mesh-clone-identity.sh

[Install]
WantedBy=multi-user.target
EOF
systemctl enable mesh-clone-identity.service

cat << EOF > /etc/systemd/system/ssh-recovery.service
[Unit]
Description=Ensure MANET SSH access is available
After=local-fs.target
Before=network-online.target batman-enslave.service alfred.service node-manager.service hostapd.service dnsmasq.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/ssh-recovery.sh

[Install]
WantedBy=multi-user.target
EOF
systemctl enable ssh-recovery.service



# Replace wpa_supplicant with lobby channel files at boot
cat <<- EOF > /etc/systemd/system/mesh-boot-lobby.service
[Unit]
Description=Set mesh interfaces to Lobby channels
Before=wpa_supplicant@.service

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'for LOBBY_FILE in /etc/wpa_supplicant/wpa_supplicant-wlan*-lobby.conf; do [ -e "\$\$LOBBY_FILE" ] || continue; DEST_FILE="\$\${LOBBY_FILE%-lobby.conf}.conf"; cp "\$\$LOBBY_FILE" "\$\$DEST_FILE"; done'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
systemctl enable mesh-boot-lobby.service

# Get bat0 a link local address for alfred
cat <<- EOF > /etc/sysctl.d/99-batman.conf
# Enable IPv6 address generation on batman-adv interfaces
net.ipv6.conf.bat0.disable_ipv6 = 0
net.ipv6.conf.bat0.addr_gen_mode = 0
net.ipv6.conf.br0.disable_ipv6 = 0
net.ipv6.conf.br0.accept_ra = 1
EOF

# Build dependency strings to make batman-enslave service file
AFTER_DEVICES=""
WANTS_SERVICES=""
INT_CT=0
for WLAN in $(cat /var/lib/mesh_if); do
    # Skip AP interface
    if [[ -n "$AP_INTERFACE" ]] && [[ "$WLAN" == "$AP_INTERFACE" ]]; then
        ((INT_CT++))
        continue
    fi
    AFTER_DEVICES+="sys-subsystem-net-devices-$WLAN.device "
    WANTS_SERVICES+="wpa_supplicant@$WLAN.service "
    ((INT_CT++))
done
for WLAN in $(cat /var/lib/halow_if | head -n 1); do
    AFTER_DEVICES+="sys-subsystem-net-devices-$WLAN.device "
    WANTS_SERVICES+="wpa_supplicant-s1g-$WLAN.service "
    ((INT_CT++))
done

cat <<- EOF > /etc/systemd/system/batman-enslave.service
[Unit]
Description=BATMAN Advanced Interface Manager
After=network-online.target ${AFTER_DEVICES} ${WANTS_SERVICES}
Wants=network-online.target ${WANTS_SERVICES}

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/bin/batman-if-setup.sh start
ExecStop=/usr/local/bin/batman-if-setup.sh stop

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable batman-enslave.service
systemctl enable batman-enslave-watch.service

# Alfred master listener for mesh data messages
cat <<- EOF > /etc/systemd/system/alfred.service
[Unit]
Description=B.A.T.M.A.N. Advanced Layer 2 Forwarding Daemon
After=network-online.target
Wants=network-online.target
Requires=batman-enslave.service

[Service]
Type=simple
ExecStartPre=/bin/bash -c 'for i in {1..20}; do if ip -6 addr show dev bat0 | grep "inet6 fe80::" | grep -qv "tentative"; then exit 0; fi; sleep 1; done; echo "bat0 link-local IPv6 address not ready" >&2; exit 1'
ExecStart=/usr/sbin/alfred -m -i br0 -f
UMask=0000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
systemctl enable alfred.service

# Node manager: IPv4 addressing and status gossip via alfred
cat <<- EOF > /etc/systemd/system/node-manager.service
[Unit]
Description=Mesh Node Status Manager and IPv4 Coordinator
After=alfred.service
Wants=alfred.service

[Service]
Type=simple
ExecStart=/usr/local/bin/node-manager.sh
Restart=on-failure
RestartSec=15

[Install]
WantedBy=multi-user.target
EOF
systemctl enable node-manager.service

cat <<- EOF > /etc/systemd/system/syncthing-peer-manager.service
[Unit]
Description=Syncthing Peer Manager
After=syncthing@radio.service alfred.service
Wants=syncthing@radio.service alfred.service

[Service]
Type=simple
ExecStart=/usr/local/bin/syncthing-peer-manager.sh
Restart=on-failure
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF
systemctl enable syncthing-peer-manager.service

systemctl enable syncthing@radio.service

systemctl daemon-reload
systemctl enable --now nftables.service

# Install scripts for auto gateway management
cp /root/networkd-dispatcher/off /etc/networkd-dispatcher/off.d/50-gateway-disable
cp /root/networkd-dispatcher/off /etc/networkd-dispatcher/no-carrier.d/50-gateway-disable
cp /root/networkd-dispatcher/off /etc/networkd-dispatcher/degraded.d/50-gateway-disable
cp /root/networkd-dispatcher/carrier /etc/networkd-dispatcher/carrier.d/50-ethernet-detect
chmod -R 755 /etc/networkd-dispatcher

cat <<- EOF > /etc/systemd/system/ethernet-autodetect.service
[Unit]
Description=MANET Ethernet Hotplug Auto Detection
After=systemd-networkd.service batman-enslave.service
Wants=systemd-networkd.service
ConditionPathExists=/usr/local/bin/ethernet-autodetect.sh

[Service]
Type=oneshot
ExecStart=/usr/local/bin/ethernet-autodetect.sh --hotplug
TimeoutStartSec=45

[Install]
WantedBy=multi-user.target
EOF
systemctl enable ethernet-autodetect.service

cp /root/regulatory.db /lib/firmware/

cat <<- EOF > /etc/systemd/system/gateway-route-manager.service
[Unit]
Description=Mesh Gateway Route Manager
Documentation=man:batctl(8)
After=network.target node-manager.service
Wants=node-manager.service
ConditionPathExists=/usr/local/bin/gateway-route-manager.sh

[Service]
Type=simple
ExecStart=/usr/local/bin/gateway-route-manager.sh
Restart=always
RestartSec=10
User=root
StandardOutput=journal
StandardError=journal
SyslogIdentifier=gateway-route-manager

[Install]
WantedBy=multi-user.target
EOF
systemctl enable gateway-route-manager

cat <<- EOF > /etc/systemd/system/mesh-shutdown.service
[Unit]
Description=Mesh Network Graceful Shutdown
DefaultDependencies=no
Before=shutdown.target reboot.target halt.target
Requires=alfred.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/mesh-shutdown.sh
TimeoutStartSec=10
RemainAfterExit=yes

[Install]
WantedBy=halt.target reboot.target shutdown.target
EOF
systemctl enable mesh-shutdown.service


# Power saving
cat << EOF > /etc/systemd/system/cpu-powersave.service
[Unit]
Description=Set CPU to powersave mode
After=multi-user.target

[Service]
Type=oneshot
RemainAfterExit=yes

# Set governor
ExecStart=/bin/bash -c 'echo powersave > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor'
# Cap max frequency to 1.0 GHz
ExecStart=/bin/bash -c 'echo 1008000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq'
# Disable cores 2 and 3
ExecStart=/bin/bash -c 'echo 0 > /sys/devices/system/cpu/cpu2/online'
ExecStart=/bin/bash -c 'echo 0 > /sys/devices/system/cpu/cpu3/online'

# Restore on stop (or when election scripts call systemctl stop cpu-powersave)
ExecStop=/bin/bash -c 'echo 1 > /sys/devices/system/cpu/cpu2/online'
ExecStop=/bin/bash -c 'echo 1 > /sys/devices/system/cpu/cpu3/online'
ExecStop=/bin/bash -c 'echo ondemand > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor'
ExecStop=/bin/bash -c 'echo 1416000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq'

[Install]
WantedBy=multi-user.target
EOF
systemctl enable cpu-powersave



cat << EOF > /etc/systemd/system/mesh-hosts-update.service
[Unit]
Description=Update /etc/hosts from mesh registry
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/mesh-hosts-update.sh
EOF

cat << EOF > /etc/systemd/system/mesh-hosts-update.timer
[Unit]
Description=Refresh mesh hosts periodically

[Timer]
OnBootSec=60
OnUnitActiveSec=120

[Install]
WantedBy=timers.target
EOF

systemctl enable mesh-hosts-update.timer


# ============================================================================
# === HOSTNAME ===
# ============================================================================

HOST_MAC=$(ip a | grep -A1 $(networkctl | grep -v bat | awk '/ether/ {print $2}' | head -1) \
   | awk '/ether/ {print $2}' | cut -d':' -f 5-6 | sed 's/://g')

set_mesh_hostname "mesh-${HOST_MAC}"

# ============================================================================
# === Web Status / config ===
# ============================================================================
cat << EOF > /etc/systemd/system/mesh-status.service
[Unit]
Description=MANET Node Status Web Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/mesh-status.py 80
Restart=on-failure
RestartSec=5
User=root
# Allows reading /etc/mesh.conf (contains credentials) and calling batctl
AmbientCapabilities=CAP_NET_RAW CAP_NET_ADMIN

[Install]
WantedBy=multi-user.target
EOF

systemctl enable mesh-status

# ============================================================================
# === mDNS — manet.local ===
# ============================================================================
# Advertise this node as manet.local on the AP/EUD interface only. One record,
# port 80 — the management UI lives at /manage on the same server now, so
# there is no second port to advertise.
# avahi-daemon is kept but restricted to deny mesh interfaces (bat0, wlan0-2).
# Clients connected to the EUD AP can reach the admin panel at http://manet.local

if have_package_network; then
    provision_try "apt install failed: avahi-daemon iperf3 traceroute sqlite3 python3-zeroconf" \
        apt install -y avahi-daemon iperf3 traceroute sqlite3 python3-zeroconf
else
    provision_fail "no network: cannot install avahi-daemon iperf3 traceroute sqlite3 python3-zeroconf"
fi
install -m 644 /etc/avahi/avahi-daemon.conf /etc/avahi/avahi-daemon.conf.bak 2>/dev/null || true
cp /usr/local/share/manet/avahi-daemon.conf /etc/avahi/avahi-daemon.conf
# Restrict avahi to the AP-only interface so nodes on the mesh don't conflict on 'manet'
AVAHI_AP_IF=$(head -1 /var/lib/no_mesh_if 2>/dev/null)
if [ -n "$AVAHI_AP_IF" ]; then
    sed -i "s/allow-interfaces=.*/allow-interfaces=$AVAHI_AP_IF/" /etc/avahi/avahi-daemon.conf
fi
cp /usr/local/share/manet/manet-http.service /etc/avahi/services/manet-http.service
# Left over from when the dashboard was its own service on port 8081.
rm -f /etc/avahi/services/perf-http.service
if systemctl list-unit-files perf-dashboard.service >/dev/null 2>&1; then
    systemctl disable --now perf-dashboard.service 2>/dev/null || true
    rm -f /etc/systemd/system/perf-dashboard.service
    systemctl daemon-reload
fi

systemctl enable avahi-daemon
systemctl restart avahi-daemon || true

# ============================================================================
# === UPS HAT (E) BATTERY MONITOR ===
# ============================================================================

# Enable I2C for battery fuel gauge (Waveshare UPS HAT E — IP2368 MCU at 0x2D)
# Bookworm+: /boot/firmware/config.txt; older images: /boot/config.txt
for _cfg in /boot/firmware/config.txt /boot/config.txt; do
    [ -f "$_cfg" ] || continue
    if ! grep -q '^dtparam=i2c_arm=on$' "$_cfg"; then
        # Remove any existing i2c_arm line then append the correct one
        sed -i '/^dtparam=i2c_arm/d' "$_cfg"
        echo "dtparam=i2c_arm=on" >> "$_cfg"
        echo " > I2C enabled in $_cfg"
    fi
done

# ============================================================================
# === RPi config.txt — SPI, Morse HaLow overlay, CM4 PCIe 32-bit DMA ===
# ============================================================================
# The Morse mm610x HaLow chip uses SPI on CM4 and RPi5 (Seeed-style SPI hat):
# config.txt must load the DT overlay, enable SPI, and drive GPIO 3/7/17 HIGH at
# boot (Morse power/reset pins). Boards carrying a USB MM81xx card instead need
# none of that — the card enumerates on USB and the SPI overlay only creates a
# phantom spi0.0 that fails probe every boot ("morse_spi_probe failed"), while
# gpio=3=op,dh fights dtparam=i2c_arm=on for the same pin. CM4 nodes with a PCIe
# mt7916 WiFi card also need pcie-32bit-dma: the BCM2711 PCIe outbound window
# sits above 4GB and the card fails probe with -ENOMEM without 32-bit DMA.
_config_txt_changed=0
if has_usb_morse_device; then
    _halow_on_spi=0
    echo " > USB Morse HaLow card present — skipping SPI overlay/GPIO config.txt entries"
else
    _halow_on_spi=1
fi
for _cfg in /boot/firmware/config.txt /boot/config.txt; do
    [ -f "$_cfg" ] || continue

    if [ "$_halow_on_spi" -eq 1 ]; then
        if ! grep -q 'dtparam=spi=on' "$_cfg"; then
            echo "dtparam=spi=on" >> "$_cfg"
            echo " > SPI enabled in $_cfg"
            _config_txt_changed=1
        fi
        if ! grep -q 'mm610x-spi' "$_cfg"; then
            echo "dtoverlay=mm610x-spi.dtbo" >> "$_cfg"
            echo " > mm610x-spi HaLow overlay added to $_cfg"
            _config_txt_changed=1
        fi
        for _gpio_line in "gpio=3=op,dh" "gpio=7=op,dh" "gpio=17=op,dh"; do
            if ! grep -qF "$_gpio_line" "$_cfg"; then
                echo "$_gpio_line" >> "$_cfg"
                _config_txt_changed=1
            fi
        done
        echo " > Morse GPIO power/reset pins set in $_cfg"
    fi

    # CM4 only: PCIe WiFi cards (mt7916) need 32-bit DMA — the BCM2711 PCIe
    # outbound window is above 4GB which the card cannot address otherwise.
    if grep -q 'Compute Module 4' /proc/device-tree/model 2>/dev/null; then
        if ! grep -q 'pcie-32bit-dma' "$_cfg"; then
            printf '\n[cm4]\ndtoverlay=pcie-32bit-dma\n' >> "$_cfg"
            echo " > pcie-32bit-dma added to $_cfg for CM4 PCIe WiFi"
            _config_txt_changed=1
        fi
    fi
done

if [ "$_config_txt_changed" -eq 1 ]; then
    echo " > config.txt modified — a reboot is needed to apply overlay changes"
    echo " > On a standard provision flow this should have been written by provision-mesh.sh"
fi

# RPi5 uses i2c_designware — i2c-dev module must load at boot for /dev/i2c-1
if ! grep -q '^i2c-dev$' /etc/modules 2>/dev/null; then
    echo 'i2c-dev' >> /etc/modules
    echo " > i2c-dev added to /etc/modules"
fi

# Install smbus and i2c-tools for battery-reader.py and diagnostics
if have_package_network; then
    provision_try "apt install failed: python3-smbus i2c-tools" \
        sh -c 'apt update -qq && apt install -y python3-smbus i2c-tools'
else
    provision_fail "no network: cannot install python3-smbus i2c-tools"
fi

systemctl enable battery-reader.service

# ============================================================================
# === GPS — u-blox USB dongle + chrony SHM NTP ===
# ============================================================================
# Supports optional u-blox 7 (USB VID 1546:01a7) GPS receivers.
# Nodes without a dongle still run gps-reader.service safely — it writes
# has_fix=false when gpsd is unreachable or has no fix.
#
# NTP strategy — sync once, then stop. Continuous polling is not worth the
# HaLow airtime for a deployment measured in days, and a second of skew does
# not matter. Only nodes that cost nothing to keep synced stay synced:
#   - GPS fix: disciplines from the SHM 0 refclock, which is shared memory
#     rather than a peer, so it costs no traffic at all. Such a node keeps
#     chrony running and serves the mesh. node-manager marks it with
#     /var/run/mesh-ntp-gps.state.
#   - Ethernet gateway: syncs from pool.ntp.org over the wire, not over the
#     mesh, and also serves. ethernet-autodetect.sh marks it with
#     /var/run/mesh-ntp.state.
#   - Everyone else: one-shot-time-sync.sh syncs once against whichever of
#     those peers has the best TQ, then stops chrony for the rest of the boot.
#
# is_ntp_server in telemetry is the OR of the two markers, which is what makes
# a GPS node discoverable as a time source. An earlier note here claimed this
# happened by itself through stratum comparison — it did not. GPS-less nodes
# do not run chrony at all, so there was no stratum to compare, and GPS was
# never wired into the election.

if have_package_network; then
    provision_try "apt install failed: gpsd gpsd-clients" \
        apt-get install -y gpsd gpsd-clients
else
    provision_fail "no network: cannot install gpsd gpsd-clients"
fi

# /etc/default/gpsd — hotplug via gpsd's own udev rules (USBAUTO=true).
# DEVICES="" means gpsd starts without a fixed device path and picks up
# any GPS device added after boot through its udev integration.
cat > /etc/default/gpsd <<'GPSD_CONF'
DEVICES=""
GPSD_OPTIONS="-n"
START_DAEMON="true"
USBAUTO="true"
GPSD_CONF

# Patch chrony configs — add SHM 0 refclock and IPv4 mesh allow if absent.
# ethernet-autodetect.sh can replace chrony.conf from these templates, so all
# available templates must carry the GPS/mesh-NTP additions too.
ensure_chrony_gps_config() {
    local conf="$1"
    [ -f "$conf" ] || return 0

    if ! grep -q 'refclock SHM 0' "$conf"; then
        cat >> "$conf" <<'CHRONY_GPS'

# GPS SHM refclock — populated by gpsd when a GPS dongle is present.
# SHM 0 = NMEA sentences (~100 ms accuracy, stratum 0 source).
# Nodes without a dongle: gpsd is not running so this refclock stays
# unreachable and chrony ignores it transparently.
refclock SHM 0 refid GPS precision 1e-1 delay 0.2 poll 4 offset 0.0
CHRONY_GPS
        echo " > chrony: SHM 0 refclock added to $conf"
    fi
    if ! grep -q 'allow 10\.30\.2\.' "$conf"; then
        echo "allow 10.30.2.0/24" >> "$conf"
        echo " > chrony: allow 10.30.2.0/24 added to $conf"
    fi
}

# Seed chrony-default.conf when it is missing. Nodes provisioned before the
# path fix got this written to /etc/chrony-default.conf, one directory too
# high, where chronyd never reads it. Both ethernet-autodetect.sh and the
# networkd-dispatcher off hook cp this file over chrony.conf after stopping
# chrony; when it does not exist the cp fails silently and the node is left
# stopped with the throwaway test config still in place.
if [ ! -f /etc/chrony/chrony-default.conf ]; then
    cat > /etc/chrony/chrony-default.conf <<'CHRONY_DEFAULT'
# Default client config: chronyd starts with no network time sources, so it
# generates no traffic until one is added. This carried a bare "offline"
# directive until that was found to be invalid — chronyd refused to start at
# all. With no sources configured the intended effect is the same.
driftfile /var/lib/chrony/chrony.drift
makestep 1.0 3
deny all
CHRONY_DEFAULT
    echo " > chrony: seeded missing /etc/chrony/chrony-default.conf"
fi

for chrony_conf in \
    /etc/chrony/chrony.conf \
    /etc/chrony/chrony-default.conf \
    /etc/chrony/chrony-server.conf \
    /etc/chrony/chrony-test.conf; do
    ensure_chrony_gps_config "$chrony_conf"
done

systemctl enable gps-reader.service
systemctl restart gps-reader.service 2>/dev/null || true
systemctl restart chrony 2>/dev/null || true

# provision-mesh.sh writes this unit but leaves it disabled, with a note saying
# radio-setup would enable it. That never happened, so the one-shot mesh time
# sync has never run on any node. Nodes that are their own time source — GPS
# fix, or Ethernet gateway — exit from it immediately and keep chrony running.
systemctl enable one-shot-time-sync.service 2>/dev/null || true

# ============================================================================
# === FIRST RUN vs RE-RUN ===
# ============================================================================

# Determine if this script is being run by the first-boot systemd unit. When
# interface renames are staged, keep the unit enabled until the post-reboot run
# finishes; disabling before that leaves provisioning half-complete.
FIRST_BOOT_UNIT_ENABLED=0
if systemctl is-enabled radio-setup-run-once.service >/dev/null 2>&1; then
    FIRST_BOOT_UNIT_ENABLED=1
fi
FIRST_BOOT_STAGE_MARKER="/var/lib/radio-setup-first-stage.done"

if [[ "$FIRST_BOOT_UNIT_ENABLED" -eq 1 && ! -f "$FIRST_BOOT_STAGE_MARKER" ]]; then
    apt remove -y network-manager
    systemctl mask rpi-eeprom-update.service
    systemctl set-default multi-user.target

    echo " >> Doing initial Syncthing config..."
    install -d -o radio -g radio -m 700 /home/radio/.local/state/syncthing
    # syncthing's apt post-install may have already created .local as radio:root;
    # install -d skips chown on pre-existing directories, so fix it explicitly.
    chown radio:radio /home/radio/.local
    sudo -u radio syncthing -generate="/home/radio/.config/syncthing"
    sleep 5
    killall syncthing
    mkdir -p /home/radio/Sync/mumble/backups
    chown -R radio:radio /home/radio/Sync
    chown -R radio:radio /home/radio/.config/syncthing

    SYNCTHING_CONFIG="/home/radio/.config/syncthing/config.xml"
    echo " >> Hardening Syncthing for local-only operation..."
    sed -i '/<options>/a <globalAnnounceEnabled>false</globalAnnounceEnabled>\n<relaysEnabled>false</relaysEnabled>' "$SYNCTHING_CONFIG"
    sed -i 's|<gui enabled="true" tls="false" debugging="false">.*</gui>|<gui enabled="true" tls="false" debugging="false">\n        <address>127.0.0.1:8384</address>\n    </gui>|' "$SYNCTHING_CONFIG"
    echo " -- CONFIGURED -- " >> /etc/issue
    touch "$FIRST_BOOT_STAGE_MARKER"
fi

# networkd-dispatcher hardening (two stock-default issues, both bite Rock 3A).
#
# 1) The stock unit has no ordering dependency, so at boot it can start before
#    systemd-networkd and dbus. Its constructor runs `networkctl list`; with no
#    networkd to answer that can wedge. Pin the ordering via a drop-in.
# 2) The Debian default /etc/default/networkd-dispatcher passes
#    `--run-startup-triggers`, which makes the daemon run every interface's state
#    hooks BEFORE signalling readiness. Hook evaluation shells out to
#    `iw <iface> link` / `networkctl status <iface>` with no timeout; on the USB
#    Morse HaLow card (wlan2) that call blocks while the firmware is still coming
#    up at boot, so the service never reaches READY and systemd kills it on the
#    start timeout. The hooks still fire on real carrier/routable state changes
#    (and MANET drives uplink/gateway detection independently via
#    ethernet-autodetect), so the boot-time pre-trigger is not needed. CM4 (SPI
#    Morse) tolerates it but we disable it everywhere for uniform behaviour.
DISPATCHER_DROPIN_DIR=/etc/systemd/system/networkd-dispatcher.service.d
if [ ! -f "$DISPATCHER_DROPIN_DIR/10-manet-ordering.conf" ]; then
    mkdir -p "$DISPATCHER_DROPIN_DIR"
    cat <<-EOF > "$DISPATCHER_DROPIN_DIR/10-manet-ordering.conf"
	[Unit]
	After=systemd-networkd.service dbus.service
	Wants=systemd-networkd.service
	EOF
    systemctl daemon-reload
    echo " > Installed networkd-dispatcher ordering drop-in"
fi
if grep -q 'run-startup-triggers' /etc/default/networkd-dispatcher 2>/dev/null; then
    cat <<-'EOF' > /etc/default/networkd-dispatcher
	# Specify command line options here. This config file is used
	# by the included systemd service file.
	# MANET: --run-startup-triggers removed — it blocks startup on the USB Morse
	# HaLow card (iw/networkctl with no timeout while the firmware inits at boot).
	networkd_dispatcher_args=""
	EOF
    echo " > Disabled networkd-dispatcher --run-startup-triggers"
fi

echo " > restarting networkd..."
systemctl restart systemd-networkd

echo " > restarting mesh supplicants..."
for WLAN in $(cat /var/lib/mesh_if 2>/dev/null); do
    if [[ -n "$AP_INTERFACE" ]] && [[ "$WLAN" == "$AP_INTERFACE" ]]; then
        continue
    fi
    systemctl reset-failed wpa_supplicant@$WLAN.service 2>/dev/null || true
    systemctl restart wpa_supplicant@$WLAN.service 2>/dev/null || true
done

echo " > resetting ipv4..."
systemctl restart node-manager

sleep 6 # wait for wpa_supplicant to catch up
echo " > resetting BATMAN-ADV bond..."
systemctl restart batman-enslave.service

echo " > restarting alfred..."
systemctl restart alfred.service

sleep 2
networkctl
iw dev
ip -br a

echo heartbeat > /sys/class/leds/ACT/trigger

if [ -f /var/lib/radio-setup-reboot-pending ]; then
    rm -f /var/lib/radio-setup-reboot-pending
    echo ""
    echo "=================================================="
    echo " Interface renames pending - rebooting in 5s"
    echo " radio-setup will re-run automatically after boot"
    echo "=================================================="
    sleep 5
    reboot
fi

# ============================================================================
# === DID THIS ACTUALLY WORK? ===
# ============================================================================
# Everything above continues past failures on purpose — a node with no GPS
# tooling still meshes. What is not acceptable is calling such a node finished.
# If anything was recorded as failed, leave the first-boot unit enabled so the
# next boot retries, and leave the node visibly unprovisioned.
PROVISION_FAILURES=0
[ -s "$PROVISION_FAIL_FILE" ] && PROVISION_FAILURES=$(wc -l < "$PROVISION_FAIL_FILE")

if [ "$PROVISION_FAILURES" -gt 0 ]; then
    provision_state incomplete "$(date +%s)"
    echo ""
    echo "=================================================="
    echo " PROVISIONING INCOMPLETE — $PROVISION_FAILURES step(s) failed"
    sed 's/^/   - /' "$PROVISION_FAIL_FILE"
    echo ""
    echo " This node has NOT been marked provisioned."
    echo " Reconnect Ethernet and reboot, or re-run this script."
    echo " Failures: $PROVISION_FAIL_FILE"
    echo "=================================================="
    echo ""
    # Leave radio-setup-run-once.service enabled: the next boot retries.
    echo heartbeat > /sys/class/leds/PWR/trigger 2>/dev/null || true
    exit 1
fi

provision_state complete "$(date +%s)"

if [[ "$FIRST_BOOT_UNIT_ENABLED" -eq 1 ]]; then
    echo " >> Removing radio-setup-run-once.service"
    systemctl disable radio-setup-run-once.service
    rm -f "$FIRST_BOOT_STAGE_MARKER"
    touch /var/lib/radio-setup.done
fi

# ============================================================================
# === OPERATOR SETUP SCRIPTS ===
# ============================================================================
# Last thing, and only on a run that got this far — past the failure gate above
# and past the rename-reboot branch, so the node is a working mesh node before
# anybody else's code touches it.
#
# --now starts it immediately instead of waiting for a reboot that a clean run
# never performs. --no-block means operator code cannot hold radio-setup open:
# systemd owns the run from here, and the unit's own conditions make it
# one-time (see manet-user-scripts.service). Safe to reach on a re-run — the
# completion marker makes systemd skip the unit.
#
# Failures in there are advisory by design and are reported on the login
# banner; they must not affect the provisioning verdict already reached above.
if [ -x /usr/local/bin/manet-user-scripts.sh ] && [ -d /var/lib/manet-user-scripts ]; then
    if [ -f /var/lib/manet-user-scripts.done ]; then
        echo " >> Operator setup scripts already ran (see /var/log/manet-user-scripts.log)"
    else
        echo " >> Starting operator setup scripts"
        systemctl enable manet-user-scripts.service 2>/dev/null || true
        systemctl start --no-block manet-user-scripts.service 2>/dev/null || true
    fi
fi

echo " >> Provisioning complete: $(date -Is)"
