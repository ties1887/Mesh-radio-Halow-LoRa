#!/bin/bash
# ==============================================================================
# Tourguide Manager
# ==============================================================================
# Handles tourguide election, radio hopping, broadcasting, and partition detection
# Called by node-manager.sh during tourguide windows
# ==============================================================================

CONTROL_IFACE="br0"
ALFRED_HELPER_TYPE=69
REGISTRY_STATE_FILE="/var/run/mesh_node_registry"
WPA_IFACE_2_4=""
WPA_IFACE_5_0=""
WPA_CONF_2_4=""
WPA_CONF_5_0=""
LOBBY_FREQ_2_4=2412
LOBBY_FREQ_5_0=5180
HELPER_STALE_SECONDS=300  # Ignore foreign helper beacons older than this
ENCODER_PATH="/usr/local/bin/encoder.py"
BATCTL_PATH="/usr/sbin/batctl"
ELECTION_OUTPUT_FILE="/var/run/mesh_channel_election"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] - TOURGUIDE: $1" | systemd-cat -t tourguide-manager
}

get_current_freq() {
    local conf_file=$1
    if [ -f "$conf_file" ]; then
        grep -oP 'frequency=\K[0-9]+' "$conf_file" | head -1
    else
        echo ""
    fi
}

load_mesh_roles() {
    local mesh_ifaces=()

    [ -f /var/lib/mesh_if ] && mapfile -t mesh_ifaces < /var/lib/mesh_if

    WPA_IFACE_2_4="$(cat /var/lib/mesh_24_if 2>/dev/null || true)"
    WPA_IFACE_5_0="$(cat /var/lib/mesh_5_if 2>/dev/null || true)"

    [ -z "$WPA_IFACE_2_4" ] && WPA_IFACE_2_4="${mesh_ifaces[0]:-}"
    [ -z "$WPA_IFACE_5_0" ] && WPA_IFACE_5_0="${mesh_ifaces[1]:-}"

    WPA_CONF_2_4="/etc/wpa_supplicant/wpa_supplicant-${WPA_IFACE_2_4}.conf"
    WPA_CONF_5_0="/etc/wpa_supplicant/wpa_supplicant-${WPA_IFACE_5_0}.conf"
}

is_hosting_service() {
    if systemctl is-active --quiet mediamtx.service; then
        source /etc/mesh_ipv4.conf 2>/dev/null
        local MEDIAMTX_IPV4_VIP=$(get_mediamtx_ipv4_vip "$IPV4_NETWORK")
        if ip addr show dev "$CONTROL_IFACE" | grep -q "inet $MEDIAMTX_IPV4_VIP/"; then
            return 0
        fi
    fi
    return 1
}

get_mediamtx_ipv4_vip() {
    local CIDR="$1"
    local CALC_OUTPUT=$(manet-ipcalc.sh "$CIDR" 2>/dev/null)
    local FIRST_IP=$(echo "$CALC_OUTPUT" | awk '/HostMin/ {print $2}')
    echo "${FIRST_IP%.*}.$((${FIRST_IP##*.} + 1))"
}

is_candidate_hosting_service() {
    local MAC_SANITIZED=$1
    [ ! -f "$REGISTRY_STATE_FILE" ] && return 1

    local MEDIAMTX_VAR="NODE_${MAC_SANITIZED}_IS_MEDIAMTX_SERVER"
    local IS_MEDIAMTX=$(grep "^${MEDIAMTX_VAR}=" "$REGISTRY_STATE_FILE" | cut -d'=' -f2 | tr -d "'")
    [ "$IS_MEDIAMTX" == "true" ] && return 0

    local MUMBLE_VAR="NODE_${MAC_SANITIZED}_IS_MUMBLE_SERVER"
    local IS_MUMBLE=$(grep "^${MUMBLE_VAR}=" "$REGISTRY_STATE_FILE" | cut -d'=' -f2 | tr -d "'")
    [ "$IS_MUMBLE" == "true" ] && return 0

    return 1
}

elect_tourguide() {
    local MY_MAC=$1
    local NEIGHBOR_MACS=($("$BATCTL_PATH" n | awk '/\[wlan[0-9]\]/ {print $2}' | sort -u))

    if [ ${#NEIGHBOR_MACS[@]} -eq 0 ]; then
        log "No neighbors (isolated). Electing self to find mesh."
        echo "$MY_MAC"
        return 0
    fi

    local CANDIDATES=("$MY_MAC")
    CANDIDATES+=("${NEIGHBOR_MACS[@]}")

    local WINNER_MAC=""
    local OLDEST_TIMESTAMP=$(date +%s)

    for CANDIDATE_MAC in "${CANDIDATES[@]}"; do
        local MAC_SANITIZED=$(echo "$CANDIDATE_MAC" | tr -d ':')

        if [ "$CANDIDATE_MAC" == "$MY_MAC" ]; then
            if is_hosting_service; then
                log "Skipping self (hosting service)"
                continue
            fi
        else
            if is_candidate_hosting_service "$MAC_SANITIZED"; then
                log "Skipping $CANDIDATE_MAC (hosting service)"
                continue
            fi
        fi

        local TIMESTAMP_VAR="NODE_${MAC_SANITIZED}_LAST_TOURGUIDE_TIMESTAMP"
        local CANDIDATE_TIMESTAMP=$(grep "^${TIMESTAMP_VAR}=" "$REGISTRY_STATE_FILE" 2>/dev/null | cut -d'=' -f2 | tr -d "'")
        CANDIDATE_TIMESTAMP=${CANDIDATE_TIMESTAMP:-0}

        if [ "$CANDIDATE_TIMESTAMP" -lt "$OLDEST_TIMESTAMP" ]; then
            OLDEST_TIMESTAMP=$CANDIDATE_TIMESTAMP
            WINNER_MAC=$CANDIDATE_MAC
        elif [ "$CANDIDATE_TIMESTAMP" -eq "$OLDEST_TIMESTAMP" ]; then
            if [[ -z "$WINNER_MAC" || "$CANDIDATE_MAC" < "$WINNER_MAC" ]]; then
                WINNER_MAC=$CANDIDATE_MAC
            fi
        fi
    done

    [ -z "$WINNER_MAC" ] && WINNER_MAC=$(printf "%s\n" "${CANDIDATES[@]}" | sort | head -1)

    log "Elected tourguide: $WINNER_MAC"
    echo "$WINNER_MAC"
}

select_tourguide_radio() {
    # Alternate on the GLOBAL tourguide window index, never on this node's own
    # history. Two split partitions can only discover each other if their
    # tourguides hop to the same band in the same window. The previous
    # implementation read this node's LAST_TOURGUIDE_RADIO from the registry,
    # which goes permanently out of phase the moment one side misses a window
    # (elected tourguide was excluded for hosting a service, a restart, a failed
    # hop) -- after that the two partitions hop to opposite bands every window
    # and never meet, silently disabling partition healing. That is the only
    # recovery path a 2-node mesh has: quorum-checker.sh cannot rescue an
    # isolated node below 3 remembered peers.
    #
    # 120 matches should_perform_tourguide's window in node-manager-acs.sh
    # (every even minute). This inherits the wall-clock alignment the rest of
    # the ACS pipeline already depends on; it adds no new time-sync requirement.
    local NOW=$(date +%s)
    if [ $(( (NOW / 120) % 2 )) -eq 0 ]; then
        echo "$WPA_IFACE_2_4"
    else
        echo "$WPA_IFACE_5_0"
    fi
}

hop_to_lobby_frequency() {
    local iface=$1
    local freq=$2
    local conf=$3

    sed -i "s/frequency=.*/frequency=${freq}/" "$conf"
    wpa_cli -i "$iface" reconfigure >/dev/null 2>&1

    for i in {1..20}; do
        CURRENT_FREQ=$(iw dev "$iface" info 2>/dev/null | grep -oP 'channel.*\((\K[0-9]+)' || echo "0")
        if [ "$CURRENT_FREQ" == "$freq" ]; then
            break
        fi
        sleep 0.5
    done

    # Set lobby bitrates
    if [ "$freq" == "$LOBBY_FREQ_2_4" ]; then
        iw dev "$iface" set bitrates legacy-2.4 1 2 5.5 11
    elif [ "$freq" == "$LOBBY_FREQ_5_0" ]; then
        iw dev "$iface" set bitrates legacy-5 6 9 12 18
    fi
}

hop_to_data_frequency() {
    local iface=$1
    local freq=$2
    local conf=$3

    sed -i "s/frequency=.*/frequency=${freq}/" "$conf"
    iw dev "$iface" set bitrates
    wpa_cli -i "$iface" reconfigure >/dev/null 2>&1
}

get_partition_size() {
    # Own partition size = unique batman originators + self
    echo $(( $("$BATCTL_PATH" o 2>/dev/null | awk 'NR>1 {print $1}' | sort -u | wc -l) + 1 ))
}

analyze_partition_data() {
    local payloads="$1"
    local MY_MAC=$(cat "/sys/class/net/${CONTROL_IFACE}/address")
    local MY_CHAN_2_4=$(get_current_freq "$WPA_CONF_2_4")
    local MY_CHAN_5_0=$(get_current_freq "$WPA_CONF_5_0")
    local MY_CONFIG="${MY_CHAN_2_4}-${MY_CHAN_5_0}"
    local MY_PARTITION_SIZE=$(get_partition_size)
    local NOW=$(date +%s)

    # Newest credible foreign beacon wins consideration
    local BEST_CONFIG="" BEST_SIZE=0 BEST_TS=0 BEST_MAC=""

    # Each line is "<sender mac> <base64>": the MAC is Alfred's record key,
    # which is where a beacon's identity comes from now that telemetry no
    # longer repeats it.
    while IFS=' ' read -r beacon_mac payload; do
        [ -z "$payload" ] && continue

        DECODED=$("/usr/local/bin/decoder.py" telemetry "$payload" 2>/dev/null || true)
        [ -z "$DECODED" ] && continue

        MAC_ADDRESS="${beacon_mac,,}"; DATA_CHANNEL_2_4=""; DATA_CHANNEL_5_0=""
        PARTITION_SIZE=0; LAST_SEEN_TIMESTAMP=0
        while IFS= read -r _line; do
            _varname="${_line%%=*}"
            _val="${_line#*=}"
            _val="${_val#\'}"
            _val="${_val%\'}"
            printf -v "$_varname" '%s' "$_val"
        done < <(echo "$DECODED" | grep -E "^(DATA_CHANNEL_|PARTITION_SIZE|LAST_SEEN_TIMESTAMP)")

        [ "$MAC_ADDRESS" == "$MY_MAC" ] && continue
        [[ "$DATA_CHANNEL_2_4" =~ ^[0-9]{4}$ && "$DATA_CHANNEL_5_0" =~ ^[0-9]{4}$ ]] || continue
        [[ "$PARTITION_SIZE" =~ ^[0-9]+$ ]] || PARTITION_SIZE=0
        [[ "$LAST_SEEN_TIMESTAMP" =~ ^[0-9]+$ ]] || LAST_SEEN_TIMESTAMP=0

        local CONFIG_KEY="${DATA_CHANNEL_2_4}-${DATA_CHANNEL_5_0}"
        [ "$CONFIG_KEY" == "$MY_CONFIG" ] && continue

        # Alfred keeps old beacons around: ignore stale ones, and ignore
        # beacons from nodes that are ACTIVE in my own registry (they are in
        # my partition; their beacon just predates a channel change).
        [ $((NOW - LAST_SEEN_TIMESTAMP)) -gt "$HELPER_STALE_SECONDS" ] && continue
        local MAC_SANITIZED=$(echo "$MAC_ADDRESS" | tr -d ':')
        grep -q "^NODE_${MAC_SANITIZED}_NODE_STATE='ACTIVE'" "$REGISTRY_STATE_FILE" 2>/dev/null && continue

        if [ "$LAST_SEEN_TIMESTAMP" -gt "$BEST_TS" ]; then
            BEST_CONFIG=$CONFIG_KEY
            BEST_SIZE=$PARTITION_SIZE
            BEST_TS=$LAST_SEEN_TIMESTAMP
            BEST_MAC=$MAC_ADDRESS
        fi
    done <<< "$payloads"

    [ -z "$BEST_CONFIG" ] && return

    log "!!! PARTITION: foreign partition (size $BEST_SIZE) on $BEST_CONFIG; mine (size $MY_PARTITION_SIZE) on $MY_CONFIG !!!"

    # Smaller partition migrates. Equal sizes: break the tie on MAC, lowest
    # stays put. Both tourguides run this in the same window and each sees the
    # other's MAC as BEST_MAC and its own as MY_MAC, so exactly one migrates.
    #
    # Deliberately NOT the config string (what this used to compare). A config
    # tiebreak decides a split by channel number, which biases every equal-size
    # merge toward the numerically-lower pair and can pull a node straight back
    # onto the channel it fled. Identity is neutral: the merge only has to pick
    # a winner, and the normal election re-optimises the channel on the next
    # cycle once both sides are talking again.
    #
    # BEST_MAC is the beaconing tourguide's MAC, not a stable partition
    # identity -- in partitions larger than one node the tourguide rotates, so
    # the comparison MAC can differ between windows. That is fine here: the
    # comparison is consistent within a single window, which is all that is
    # needed, and one merge resolves the split. Carrying a real partition
    # identity would mean a new NodeInfo.proto field and a pb2 regeneration
    # (protoc 3.21.x only — see the ACS section of the handoff).
    if [ "$BEST_SIZE" -gt "$MY_PARTITION_SIZE" ] || \
       { [ "$BEST_SIZE" -eq "$MY_PARTITION_SIZE" ] && [[ -n "$BEST_MAC" ]] && [[ "$BEST_MAC" < "$MY_MAC" ]]; }; then
        log "Other partition wins. Triggering migration..."
        IFS='-' read -r new_2_4 new_5_0 <<< "$BEST_CONFIG"

        cat > "$ELECTION_OUTPUT_FILE" <<-EOF
			WINNER_2_4=$new_2_4
			WINNER_5_0=$new_5_0
			LIMP_MODE=false
			PARTITION_MERGE=true
		EOF
    else
        log "My partition wins. Staying on $MY_CONFIG."
    fi
}

# === MAIN EXECUTION ===
load_mesh_roles
if [ -z "$WPA_IFACE_2_4" ] || [ -z "$WPA_IFACE_5_0" ]; then
    log "Mesh role files not ready; cannot run tourguide manager."
    exit 1
fi
MY_MAC=$(cat "/sys/class/net/${CONTROL_IFACE}/address")
NOW=$(date +%s)

# Read last tourguide state
LAST_TOURGUIDE_TIME=0
LAST_TOURGUIDE_RADIO=""
if [ -f /var/run/tourguide_state ]; then
    source /var/run/tourguide_state
fi

ELECTED_TOURGUIDE=$(elect_tourguide "$MY_MAC")

if [ "$ELECTED_TOURGUIDE" != "$MY_MAC" ]; then
    log "Tourguide is $ELECTED_TOURGUIDE. Standing by."
    exit 0
fi

log "=== I AM TOURGUIDE ==="

TOURGUIDE_RADIO=$(select_tourguide_radio)
HOSTNAME=$(hostname)

# Build helper payload (partition size lets two tourguides meeting in the
# lobby agree on which partition migrates)
HELPER_PAYLOAD=$("$ENCODER_PATH" telemetry \
    "--data-channel-2-4" "$(get_current_freq $WPA_CONF_2_4)" \
    "--data-channel-5-0" "$(get_current_freq $WPA_CONF_5_0)" \
    "--partition-size" "$(get_partition_size)" \
    "--timestamp" "$NOW" \
    2>/dev/null)

# Select lobby frequency based on radio
if [ "$TOURGUIDE_RADIO" == "$WPA_IFACE_2_4" ]; then
    LOBBY_FREQ=$LOBBY_FREQ_2_4
    TOURGUIDE_CONF=$WPA_CONF_2_4
else
    LOBBY_FREQ=$LOBBY_FREQ_5_0
    TOURGUIDE_CONF=$WPA_CONF_5_0
fi

DATA_FREQ=$(get_current_freq "$TOURGUIDE_CONF")

log "Hopping $TOURGUIDE_RADIO to lobby ($LOBBY_FREQ)..."
hop_to_lobby_frequency "$TOURGUIDE_RADIO" "$LOBBY_FREQ" "$TOURGUIDE_CONF"

sleep 3

log "Broadcasting helper beacon..."
echo -n "$HELPER_PAYLOAD" | alfred -s $ALFRED_HELPER_TYPE

log "Listening for partitions (12s)..."
sleep 12

# Check for partition
OTHER_PARTITION_DATA=$(alfred -r $ALFRED_HELPER_TYPE 2>/dev/null |
    sed -n 's/^[[:space:]]*{[[:space:]]*"\([0-9a-fA-F:]\{17\}\)"[[:space:]]*,[[:space:]]*"\([^"]*\)".*/\1 \2/p' || true)

if [ -n "$OTHER_PARTITION_DATA" ]; then
    analyze_partition_data "$OTHER_PARTITION_DATA"
fi

log "Returning to data channel ($DATA_FREQ)..."
hop_to_data_frequency "$TOURGUIDE_RADIO" "$DATA_FREQ" "$TOURGUIDE_CONF"

# Save state
cat > /var/run/tourguide_state <<EOF
LAST_TOURGUIDE_TIME=$NOW
LAST_TOURGUIDE_RADIO=$TOURGUIDE_RADIO
EOF

log "Tourguide duty complete."
exit 0
